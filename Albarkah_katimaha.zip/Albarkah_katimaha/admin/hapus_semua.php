<?php
include 'koneksi.php';

$conn->query("DELETE FROM siswa");
echo "Data terhapus";
?>
