<?php
include 'koneksi.php';

$id = $_POST['id'];
$kelas = $_POST['kelas'];

$stmt = $conn->prepare("UPDATE siswa SET kelas = ? WHERE id = ?");
$stmt->bind_param("si", $kelas, $id);

if ($stmt->execute()) {
    echo "Berhasil";
} else {
    echo "Gagal: " . $stmt->error;
}
