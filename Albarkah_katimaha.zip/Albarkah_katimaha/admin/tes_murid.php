<?php
include 'koneksi.php'; // pastikan file koneksi tersedia

// Pagination
$limit = 10;
$page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
$start = ($page - 1) * $limit;

// Ambil total data
$totalResult = $conn->query("SELECT COUNT(*) AS total FROM siswa");
$totalRow = $totalResult->fetch_assoc()['total'];
$totalPages = ceil($totalRow / $limit);

// Ambil data siswa
$query = "SELECT siswa.*, nilai.nilai 
          FROM siswa 
          LEFT JOIN nilai ON siswa.id = nilai.siswa_id 
          ORDER BY siswa.tanggal_daftar DESC 
          LIMIT $start, $limit";

$result = $conn->query($query);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Tes Murid</title>
    <link rel="stylesheet" href="../assets/css/tes_murid.css">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>

    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <style>
        .pagination a {
            margin: 0 5px;
            text-decoration: none;
        }
        .btn {
            padding: 5px 10px;
            
            color: white;
            border: none;
            cursor: pointer;
            padding: 12px 8px;
        }
    </style>
</head>
<body>

    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <!-- Logo placeholder -->
            <img src="../images/logo.png" alt="Logo">
        </div>
        <ul class="sidebar-menu">
    <li>
        <a href="dashboard.php"><img src="../images/dashboard.png" alt="Dashboard">
            <span>Dashboard</span>
        </a>
    </li>
    <li>
        <a href="manajemen_siswa.php"><img src="../images/manajemen.png" alt="Manajemen Siswa">
            <span>Manajemen Siswa</span>
        </a>
    </li>
    <li>
        <a href="tes_murid.php"><img src="../images/tes.png" alt="Tes Murid">
            <span>Tes Murid</span>
        </a>
    </li>
    <li>
        <a href="#" id="logout-link"><img src="../images/logout.png" alt="Keluar">
            <span>Keluar</span>
        </a>
    </li>
</ul>

        <div class="datetime" id="datetime">
            <!-- DateTime will be inserted here by JavaScript -->
        </div>
    </div>


    <h2>Daftar Tes Murid</h2>
    

    <div class="table-container">
    <div class="table-wrapper">
        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Jenjang</th>
                    <th>Video Membaca</th>
                    <th>Foto Tulisan</th>
                    <th>Video Qur'an</th>
                    <th>Tanggal Daftar</th>
                    <th>Aksi</th>
                    <th>Nilai</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    $no = $start + 1;
                    while ($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>{$no}</td>";
                        echo "<td>" . htmlspecialchars($row['nama']) . "</td>";
                        echo "<td>" . htmlspecialchars($row['jenjang']) . "</td>";

                        echo "<td>";
                        if (!empty($row['video_membaca'])) {
                            echo "<a href='" . htmlspecialchars($row['video_membaca']) . "' target='_blank' class='file-link'>Lihat Video</a>";
                        } else {
                            echo "-";
                        }
                        echo "</td>";

                        echo "<td>";
                        if (!empty($row['foto_tulisan'])) {
                            echo "<a href='" . htmlspecialchars($row['foto_tulisan']) . "' target='_blank' class='file-link'>Lihat Foto</a>";
                        } else {
                            echo "-";
                        }
                        echo "</td>";

                        echo "<td>";
                        if (!empty($row['video_quran'])) {
                            echo "<a href='" . htmlspecialchars($row['video_quran']) . "' target='_blank' class='file-link'>Lihat Video</a>";
                        } else {
                            echo "-";
                        }
                        echo "</td>";

                        echo "<td>" . htmlspecialchars($row['tanggal_daftar']) . "</td>";

                        echo "<td><button class='change-status' onclick='setKelas(" . $row['id'] . ")'>Set Kelas</button></td>";
                        echo "<td>";
                        if (!is_null($row['nilai'])) {
                            echo htmlspecialchars($row['nilai']);
                        } else {
                            echo "-";
                        }
                        echo "</td>";

                        echo "</tr>";
                        $no++;
                    }
                } else {
                    echo "<tr><td colspan='8' style='text-align:center; padding: 20px; color: #888;'>Belum ada siswa yang mengerjakan tes</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>
</div>



    <div class="pagination">
        <?php for ($i = 1; $i <= $totalPages; $i++): ?>
            <a href="?page=<?= $i ?>"><?= $i ?></a>
        <?php endfor; ?>
    </div>

    <div class="tombol">
        <button class="btn btn-download" onclick="window.location.href='export_excel.php'">Download Excel</button>
        <button class="btn btn-danger" onclick="hapusSemuaData()">Hapus Semua Data</button>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Menambahkan kelas active pada elemen <li> yang diklik
        const items = document.querySelectorAll('.sidebar-menu li');
        items.forEach(item => {
            item.addEventListener('click', () => {
                items.forEach(i => i.classList.remove('active')); // Menghapus kelas active dari semua <li>
                item.classList.add('active'); // Menambahkan kelas active pada <li> yang diklik
            });
        });

        // Menambahkan kelas active pada elemen kedua saat halaman dimuat
        window.addEventListener('load', () => {
            items[2].classList.add('active'); // Menambahkan kelas active pada elemen kedua
        });
    </script>

<script>
        // Function to update date and time
        function updateDateTime() {
            const now = new Date();
            const options = {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            };
            const dateTimeStr = now.toLocaleDateString('id-ID', options);
            document.getElementById('datetime').textContent = dateTimeStr;
        }

        // Update immediately and then every second
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Tab switching functionality
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', () => {
                // Remove active class from all buttons
                document.querySelectorAll('.tab-button').forEach(btn => {
                    btn.classList.remove('active');
                });
                // Add active class to clicked button
                button.classList.add('active');
                // Here you would typically update the table content based on the selected tab
                // This will be handled by your PHP backend
            });
        });
    </script>


    <script>
        function setKelas(id) {
            Swal.fire({
                title: 'Masukkan Kelas',
                input: 'text',
                inputLabel: 'Kelas',
                inputPlaceholder: 'Contoh: 1A / 7B',
                showCancelButton: true,
                confirmButtonText: 'Simpan',
                preConfirm: (kelas) => {
                    if (!kelas) {
                        Swal.showValidationMessage('Kelas wajib diisi');
                    }
                    return kelas;
                }
            }).then((result) => {
                if (result.isConfirmed) {
                    fetch('update_kelas.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded'
                        },
                        body: `id=${id}&kelas=${encodeURIComponent(result.value)}`
                    })
                    .then(res => res.text())
                    .then(data => {
                        Swal.fire('Sukses!', 'Kelas berhasil diupdate.', 'success')
                        .then(() => location.reload());
                    })
                    .catch(err => {
                        Swal.fire('Gagal', 'Terjadi kesalahan.', 'error');
                    });
                }
            });
        }
    </script>

<script>
function hapusSemuaData() {
    Swal.fire({
        title: 'Yakin ingin menghapus semua data?',
        text: "Semua data siswa yang sudah mengikuti tes akan dihapus!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#dc2626',
        cancelButtonColor: '#6b7280',
        confirmButtonText: 'Ya, Hapus dan Download!'
    }).then((result) => {
        if (result.isConfirmed) {
            // Pertama download data
            window.open('export_excel.php', '_blank');
            
            // Lalu hapus data
            fetch('hapus_semua.php', {
                method: 'POST'
            })
            .then(res => res.text())
            .then(data => {
                Swal.fire('Sukses!', 'Semua data telah dihapus.', 'success')
                .then(() => location.reload());
            })
            .catch(err => {
                Swal.fire('Gagal', 'Terjadi kesalahan.', 'error');
            });
        }
    });
}
</script>


<script>
    // Tangkap event klik pada tombol logout
    document.getElementById('logout-link').addEventListener('click', function(event) {
        event.preventDefault(); // Mencegah link agar tidak langsung menuju logout.php

        // Tampilkan SweetAlert konfirmasi logout
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Anda akan keluar dari akun ini!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya, Logout!',
            cancelButtonText: 'Tidak, Tetap di sini!',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                // Jika user memilih 'Ya, Logout!', redirect ke logout.php
                window.location.href = '../logic/logout.php';
            }
        });
    });
</script>

</body>
</html>
