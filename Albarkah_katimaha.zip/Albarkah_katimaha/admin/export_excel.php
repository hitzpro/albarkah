<?php
include 'koneksi.php';

header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=daftar_siswa_tes.xls");

echo "<table border='1'>";
echo "<tr>
        <th>Nama</th>
        <th>Jenjang</th>
        <th>Tanggal Daftar</th>
        <th>Kelas</th>
    </tr>";

$result = $conn->query("SELECT nama, jenjang, tanggal_daftar, kelas FROM siswa ORDER BY tanggal_daftar DESC");
while ($row = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>{$row['nama']}</td>";
    echo "<td>{$row['jenjang']}</td>";
    echo "<td>{$row['tanggal_daftar']}</td>";
    echo "<td>{$row['kelas']}</td>";
    echo "</tr>";
}
echo "</table>";
?>
