<?php
// Memasukkan koneksi database
include('../config/db.php');

// Ambil ID siswa dari query parameter
$id = $_GET['id'] ?? NULL;

// Pastikan ID ada
if (!$id) {
    // Jika tidak ada ID, redirect ke halaman sebelumnya atau halaman yang aman
    header('Location: ../admin/dashboard.php');
    exit();
}

// Ambil data siswa berdasarkan ID
$query = "SELECT * FROM siswa WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('i', $id);
$stmt->execute();
$result = $stmt->get_result();
$siswa = $result->fetch_assoc();

// Jika data tidak ditemukan
if (!$siswa) {
    echo "Data tidak ditemukan.";
    exit();
}

// Variable untuk status
$status_message = '';
$status_type = '';

// Simpan perubahan jika form disubmit
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $nama_lengkap = $_POST['nama_lengkap'];
    $nama_panggilan = $_POST['nama_panggilan'];
    $tempat_tanggal_lahir = $_POST['tempat_tanggal_lahir'];
    $umur = $_POST['umur'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $anak_ke = $_POST['anak_ke'];
    $jumlah_saudara = $_POST['jumlah_saudara'];
    $alamat_murid = $_POST['alamat_murid'];
    $nisn = $_POST['nisn'];
    $nilai_akhir = $_POST['nilai_akhir'];
    $nilai_rata_rata = $_POST['nilai_rata_rata'];
    $alumni_sd = $_POST['alumni_sd'];

    // Query untuk update data
    $update_query = "UPDATE siswa SET 
        nama_lengkap = ?, 
        nama_panggilan = ?, 
        tempat_tanggal_lahir = ?, 
        umur = ?, 
        jenis_kelamin = ?, 
        anak_ke = ?, 
        jumlah_saudara = ?, 
        alamat_murid = ?, 
        nisn = ?, 
        nilai_akhir = ?, 
        nilai_rata_rata = ?, 
        alumni_sd = ? 
        WHERE id = ?";
    
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param('sssssiisssssi', 
        $nama_lengkap, $nama_panggilan, $tempat_tanggal_lahir, $umur, $jenis_kelamin,
        $anak_ke, $jumlah_saudara, $alamat_murid, $nisn, $nilai_akhir, $nilai_rata_rata, $alumni_sd, $id);
    
    if ($update_stmt->execute()) {
        // Jika berhasil, beri status
        $status_message = 'Data berhasil diubah!';
        $status_type = 'success';
    } else {
        // Jika gagal, beri status
        $status_message = 'Terdapat kesalahan saat mengubah data siswa.';
        $status_type = 'error';
    }
}
?>

<!-- HTML Form untuk Edit Data Siswa -->
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Siswa</title>
    <link rel="stylesheet" href="../assets/css/edit.css"> <!-- CSS Eksternal -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script> <!-- SweetAlert -->
</head>
<body>
    <div class="form-container">
        <h2>Edit Data Siswa</h2>
        <form action="edit_data.php?id=<?php echo $id; ?>" method="POST">
            <div class="form-group">
                <label for="nama_lengkap">Nama Lengkap</label>
                <input type="text" name="nama_lengkap" id="nama_lengkap" value="<?php echo htmlspecialchars($siswa['nama_lengkap']); ?>" required>
            </div>
            <div class="form-group">
                <label for="nama_panggilan">Nama Panggilan</label>
                <input type="text" name="nama_panggilan" id="nama_panggilan" value="<?php echo htmlspecialchars($siswa['nama_panggilan']); ?>" required>
            </div>
            <div class="form-group">
                <label for="tempat_tanggal_lahir">Tempat Tanggal Lahir</label>
                <input type="text" name="tempat_tanggal_lahir" id="tempat_tanggal_lahir" value="<?php echo htmlspecialchars($siswa['tempat_tanggal_lahir']); ?>" required>
            </div>
            <div class="form-group">
                <label for="umur">Umur</label>
                <input type="number" name="umur" id="umur" value="<?php echo $siswa['umur']; ?>" required>
            </div>
            <div class="form-group">
                <label for="jenis_kelamin">Jenis Kelamin</label>
                <select name="jenis_kelamin" id="jenis_kelamin" required>
                    <option value="Laki-laki" <?php echo $siswa['jenis_kelamin'] == 'Laki-laki' ? 'selected' : ''; ?>>Laki-laki</option>
                    <option value="Perempuan" <?php echo $siswa['jenis_kelamin'] == 'Perempuan' ? 'selected' : ''; ?>>Perempuan</option>
                </select>
            </div>
            <div class="form-group">
                <label for="anak_ke">Anak Ke</label>
                <input type="number" name="anak_ke" id="anak_ke" value="<?php echo $siswa['anak_ke']; ?>" required>
            </div>
            <div class="form-group">
                <label for="jumlah_saudara">Jumlah Saudara</label>
                <input type="number" name="jumlah_saudara" id="jumlah_saudara" value="<?php echo $siswa['jumlah_saudara']; ?>" required>
            </div>
            <div class="form-group">
                <label for="alamat_murid">Alamat Murid</label>
                <textarea name="alamat_murid" id="alamat_murid" required><?php echo htmlspecialchars($siswa['alamat_murid']); ?></textarea>
            </div>
            <div class="form-group">
                <label for="nisn">NISN</label>
                <input type="text" name="nisn" id="nisn" value="<?php echo $siswa['nisn']; ?>">
            </div>
            <div class="form-group">
                <label for="nilai_akhir">Nilai Akhir</label>
                <input type="number" name="nilai_akhir" id="nilai_akhir" value="<?php echo $siswa['nilai_akhir']; ?>">
            </div>
            <div class="form-group">
                <label for="nilai_rata_rata">Nilai Rata Rata</label>
                <input type="number" name="nilai_rata_rata" id="nilai_rata_rata" value="<?php echo $siswa['nilai_rata_rata']; ?>">
            </div>
            <div class="form-group">
                <label for="alumni_sd">Alumni SD</label>
                <input type="text" name="alumni_sd" id="alumni_sd" value="<?php echo $siswa['alumni_sd']; ?>">
            </div>

            <!-- Tombol Kembali dan Simpan -->
            <div class="form-actions">
                <a href="../admin/dashboard.php" class="btn-cancel">Kembali</a>
                <button type="submit" class="btn-save">Simpan</button>
            </div>
        </form>
    </div>

    <!-- SweetAlert JavaScript -->
    <?php if ($status_message): ?>
        <script>
            Swal.fire({
                icon: '<?php echo $status_type; ?>',
                title: '<?php echo $status_message; ?>',
                confirmButtonText: 'OK'
            }).then(() => {
                <?php if ($status_type == 'success') { ?>
                    window.location = '../admin/dashboard.php';  // Redirect jika sukses
                <?php } ?>
            });
        </script>
    <?php endif; ?>
</body>
</html>
