<?php

// Memasukkan koneksi database
include('../config/db.php');

// Mengambil jumlah seluruh pendaftar
$query_total = "SELECT COUNT(*) AS total FROM siswa";
$result_total = $conn->query($query_total);
$total_pendaftar = $result_total->fetch_assoc()['total'];

// Mengambil jumlah pendaftar TK
$query_tk = "SELECT COUNT(*) AS tk FROM siswa WHERE jenjang_pendidikan = 'TK'";
$result_tk = $conn->query($query_tk);
$tk_count = $result_tk->fetch_assoc()['tk'];

// Mengambil jumlah pendaftar SD
$query_sd = "SELECT COUNT(*) AS sd FROM siswa WHERE jenjang_pendidikan = 'SD'";
$result_sd = $conn->query($query_sd);
$sd_count = $result_sd->fetch_assoc()['sd'];

// Mengambil jumlah pendaftar SMP
$query_smp = "SELECT COUNT(*) AS smp FROM siswa WHERE jenjang_pendidikan = 'SMP'";
$result_smp = $conn->query($query_smp);
$smp_count = $result_smp->fetch_assoc()['smp'];


// Ambil parameter untuk tab yang dipilih
$tab = isset($_GET['tab']) ? $_GET['tab'] : 'TK';
$search_with_wali = isset($_GET['wali']) ? $_GET['wali'] : false;
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$limit = 10; // batas data per halaman
$offset = ($page - 1) * $limit;

// Menentukan query berdasarkan tab yang dipilih
if ($search_with_wali) {
    $query = "SELECT * FROM siswa WHERE nama_ayah IS NULL OR nama_ibu IS NULL LIMIT $limit OFFSET $offset";
} else {
    if ($tab == 'TK') {
        $query = "SELECT * FROM siswa WHERE jenjang_pendidikan = 'TK' LIMIT $limit OFFSET $offset";
    } elseif ($tab == 'SD') {
        $query = "SELECT * FROM siswa WHERE jenjang_pendidikan = 'SD' LIMIT $limit OFFSET $offset";
    } elseif ($tab == 'SMP') {
        $query = "SELECT * FROM siswa WHERE jenjang_pendidikan = 'SMP' LIMIT $limit OFFSET $offset";
    }
}

$result = $conn->query($query);
$total_rows = $conn->query("SELECT COUNT(*) AS total FROM siswa")->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $limit);

// Ambil data siswa
$siswa = [];
while ($row = $result->fetch_assoc()) {
    $siswa[] = $row;
}
?>



<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Siswa</title>
    <link rel="stylesheet" href="../assets/css/manajemen_siswa.css">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Abhaya+Libre' rel='stylesheet'>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <style>

        

    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <!-- Logo placeholder -->
            <img src="../images/logo.png" alt="Logo">
        </div>
        <ul class="sidebar-menu">
    <li>
        <a href="dashboard.php"><img src="../images/dashboard.png" alt="Dashboard">
            <span>Dashboard</span>
        </a>
    </li>
    <li>
        <a href="manajemen_siswa.php"><img src="../images/manajemen.png" alt="Manajemen Siswa">
            <span>Manajemen Siswa</span>
        </a>
    </li>
    <li>
        <a href="tes_murid.php"><img src="../images/tes.png" alt="Tes Murid">
            <span>Tes Murid</span>
        </a>
    </li>
    <li>
        <a href="#" id="logout-link"><img src="../images/logout.png" alt="Keluar">
            <span>Keluar</span>
        </a>
    </li>
</ul>

        <div class="datetime" id="datetime">
            <!-- DateTime will be inserted here by JavaScript -->
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Stats Cards -->
        <div class="stats-container">
            <div class="stat-card">
                <img src="../images/user.png" alt="TK">
                <div class="stat-info">
                    <h3>Jumlah Murid TK</h3>
                    <div class="number"><?php echo $tk_count; ?> Anak</div>
                </div>
            </div>
            <div class="stat-card">
                <img src="../images/user.png" alt="SD">
                <div class="stat-info">
                    <h3>Jumlah Murid SD</h3>
                    <div class="number"><?php echo $sd_count; ?> Anak</div>
                </div>
            </div>
            <div class="stat-card">
                <img src="../images/user.png" alt="SMP">
                <div class="stat-info">
                    <h3>Jumlah Murid SMP</h3>
                    <div class="number"><?php echo $smp_count; ?> Anak</div>
                </div>
            </div>
        </div>

        <!-- Tabs and Table -->
        <div class="tabs-container">
            <div class="tab-buttons">
                <button class="tab-button <?php echo $tab == 'TK' ? 'active' : ''; ?>" onclick="window.location='?tab=TK'">Siswa TK</button>
                <button class="tab-button <?php echo $tab == 'SD' ? 'active' : ''; ?>" onclick="window.location='?tab=SD'">Siswa SD/IT</button>
                <button class="tab-button <?php echo $tab == 'SMP' ? 'active' : ''; ?>" onclick="window.location='?tab=SMP'">Siswa SMP/IT</button>
                <button class="tab-button <?php echo $search_with_wali ? 'active' : ''; ?>" onclick="window.location='?wali=true'">Siswa Dengan Wali</button>
            </div>

            <div class="table-container">
            <div class="table-wrapper">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nama</th>
                            <th>Umur</th>
                            <th>Kelas</th>
                            <th>Alamat</th>
                            <th>Akte Kelahiran</th>
                            <th>Kartu Keluarga</th>
                            <th>Foto Murid</th>
                            <th>Bukti Pembayaran</th>
                            <th>Status</th>
                            <th>Nomor Telepon</th>
                            <th>Status Pindahan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody id="student-table-body">
                        <?php if (count($siswa) > 0): ?>
                            <?php foreach ($siswa as $index => $row): ?>
                                <tr>
                                    <td><?php echo $index + 1 + $offset; ?></td>
                                    <td><?php echo htmlspecialchars($row['nama_lengkap']); ?></td>
                                    <td><?php echo $row['umur']; ?></td>
                                    <td><?php echo $row['jenjang_pendidikan']; ?></td>
                                    <td><?php echo htmlspecialchars($row['alamat_murid']); ?></td>
                                    <?php
                                        // Ambil data dari $row yang mewakili satu siswa
                                        $jenjang = $row['jenjang_pendidikan']; // Jenjang pendidikan (misalnya, SD, SMP)
                                        $nama_lengkap = urlencode($row['nama_lengkap']); // Nama lengkap siswa yang telah di-encode untuk URL

                                        // Tentukan path folder berdasarkan jenjang pendidikan
                                        $basePath = "../uploads/{$jenjang}/"; // Lokasi folder jenjang pendidikan

                                        // Tentukan folder untuk kelengkapan dan pembayaran berdasarkan nama siswa
                                        $folderKelompok = "{$basePath}kelengkapan_" . str_replace(' ', '_', $row['nama_lengkap']);
                                        $folderPembayaran = "{$basePath}bukti_pembayaran_" . str_replace(' ', '_', $row['nama_lengkap']);

                                        // Tentukan path file
                                        $akteKelahiranLink = "{$folderKelompok}/akteKelahiran_{$row['id']}.pdf";
                                        $kartuKeluargaLink = "{$folderKelompok}/kartuKeluarga_{$row['id']}.pdf";
                                        $fotoMuridLink = "{$folderKelompok}/fotoMurid_{$row['id']}.jpg"; // Atau .png
                                        $buktiPembayaranLink = "{$folderPembayaran}/buktiPembayaran_{$row['id']}.jpg"; // Atau .png, .pdf
                                        $buktiKtpLink = "{$folderKelompok}/buktiKtp_{$row['id']}.pdf"; // Atau .jpg

                                        // Menampilkan link ke file dengan target _blank untuk membuka di tab baru
                                        echo "<td><a href='{$akteKelahiranLink}' target='_blank' class='file-link'>Lihat Akte Kelahiran</a></td>";
                                        echo "<td><a href='{$kartuKeluargaLink}' target='_blank' class='file-link'>Lihat Kartu Keluarga</a></td>";
                                        echo "<td><a href='{$fotoMuridLink}' target='_blank' class='file-link'>Lihat Foto Murid</a></td>";
                                        echo "<td><a href='{$buktiPembayaranLink}' target='_blank' class='file-link'>Lihat Bukti Pembayaran</a></td>";
                                        // Cek status
                                        $status_class = '';
                                        $status_text = $row['status']; // Ambil status dari database

                                        // Tentukan kelas CSS untuk status
                                        if ($status_text == 'Pending') {
                                            $status_class = 'status-pending';
                                        } elseif ($status_text == 'Ditolak') {
                                            $status_class = 'status-ditolak';
                                        } elseif ($status_text == 'Diterima') {
                                            $status_class = 'status-diterima';
                                        }
                                        ?>
                                        <td class="status-col">
                                            <a href="javascript:void(0);" class="change-status"
                                                data-id="<?= $row['id'] ?>"
                                                data-status="<?= $row['status'] ?>">
                                                <?= $row['status'] ?>
                                            </a>
                                        </td>



                                        <td class="telepon-col" data-nama="<?= $row['nama_lengkap'] ?>" data-telp="<?= $row['nomer_telepon_ortu'] ?>">
                                            <?= $row['nomer_telepon_ortu'] ?: '-' ?>
                                        </td>

                                        <td class="status-pindahan-col" data-nama="<?= $row['nama_lengkap'] ?>" data-status-pindahan="<?= $row['status_pindahan'] ?>">
                                            <?= $row['status_pindahan'] ?: '-' ?>
                                        </td>



                                    <td>
                                        <a href="edit_data.php?id=<?php echo $row['id']; ?>" class="action-link">Edit</a> |
                                        <!-- Hapus Link -->
                                        <a href="javascript:void(0);" class="action-link" onclick="confirmDelete(<?php echo $row['id']; ?>)">Hapus</a>

                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="11">Tidak ada data siswa yang memenuhi kriteria.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>


    <div class="pagination">
        <?php if ($total_pages > 1): ?>
            <ul>
                <li><a href="?tab=<?php echo $tab; ?>&page=1">First</a></li>
                <li><a href="?tab=<?php echo $tab; ?>&page=<?php echo $page > 1 ? $page - 1 : 1; ?>">Prev</a></li>
                <li><a href="?tab=<?php echo $tab; ?>&page=<?php echo $page < $total_pages ? $page + 1 : $total_pages; ?>">Next</a></li>
                <li><a href="?tab=<?php echo $tab; ?>&page=<?php echo $total_pages; ?>">Last</a></li>
            </ul>
        <?php endif; ?>
    </div>
</div>

<!-- Action Buttons -->
<div class="action-buttons">
    <button class="download-button" onclick="downloadData()">Download Data Excel</button>
    <button class="delete-button" onclick="confirmDeleteAll()">Hapus Semua Data</button>
</div>






    <script>
        // Function to update date and time
        function updateDateTime() {
            const now = new Date();
            const options = {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            };
            const dateTimeStr = now.toLocaleDateString('id-ID', options);
            document.getElementById('datetime').textContent = dateTimeStr;
        }

        // Update immediately and then every second
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Tab switching functionality
        document.querySelectorAll('.tab-button').forEach(button => {
            button.addEventListener('click', () => {
                // Remove active class from all buttons
                document.querySelectorAll('.tab-button').forEach(btn => {
                    btn.classList.remove('active');
                });
                // Add active class to clicked button
                button.classList.add('active');
                // Here you would typically update the table content based on the selected tab
                // This will be handled by your PHP backend
            });
        });
    </script>


<script>
// Menambahkan kelas active pada elemen <li> yang diklik
const items = document.querySelectorAll('.sidebar-menu li');
items.forEach(item => {
    item.addEventListener('click', () => {
        items.forEach(i => i.classList.remove('active')); // Menghapus kelas active dari semua <li>
        item.classList.add('active'); // Menambahkan kelas active pada <li> yang diklik
    });
});

// Menambahkan kelas active pada elemen kedua saat halaman dimuat
window.addEventListener('load', () => {
    items[1].classList.add('active'); // Menambahkan kelas active pada elemen kedua
});
</script>






<!-- script logout -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<script>
document.addEventListener('DOMContentLoaded', function () {
    attachStatusChangeListeners();
    attachWaButtonListeners();
});

function attachStatusChangeListeners() {
    document.querySelectorAll('.change-status').forEach(link => {
        link.addEventListener('click', handleStatusChange);
    });
}

function handleStatusChange() {
    const siswaId = this.getAttribute('data-id');
    const currentStatus = this.getAttribute('data-status');

    Swal.fire({
        title: 'Pilih Status Baru',
        input: 'select',
        inputOptions: {
            'Pending': 'Pending',
            'Diterima': 'Diterima',
            'Ditolak': 'Ditolak'
        },
        inputValue: currentStatus,
        showCancelButton: true,
        confirmButtonText: 'Update Status',
        cancelButtonText: 'Batal',
        inputValidator: value => !value && 'Status harus dipilih!'
    }).then(result => {
        if (result.isConfirmed) {
            updateStatus(siswaId, result.value, this);
        }
    });
}

function updateStatus(siswaId, newStatus, linkElement) {
    fetch('../logic/update_status.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `id=${siswaId}&status=${newStatus}`
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            Swal.fire('Berhasil!', 'Status telah diperbarui.', 'success').then(() => {
                updateUI(siswaId, newStatus, linkElement);
            });
        } else {
            Swal.fire('Gagal!', 'Terjadi kesalahan saat memperbarui status.', 'error');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        Swal.fire('Error', 'Terjadi kesalahan saat memproses permintaan.', 'error');
    });
}

function updateUI(siswaId, newStatus, linkElement) {
    const row = linkElement.closest('tr');

    // Update status cell
    const statusCell = row.querySelector('td.status-col');
    if (statusCell) {
        statusCell.innerHTML = `<a href="javascript:void(0);" class="change-status" data-id="${siswaId}" data-status="${newStatus}">${newStatus}</a>`;
    }

    // Update telepon cell jika diterima
    const teleponCol = row.querySelector('.telepon-col');
    if (teleponCol) {
        const nama = teleponCol.getAttribute('data-nama');
        const telp = teleponCol.getAttribute('data-telp');

        if (newStatus === 'Diterima' && telp && telp !== '-') {
            teleponCol.innerHTML = `
                <button class="btn btn-sm btn-success open-wa-swal"
                    data-phone="${telp}"
                    data-nama="${nama}">
                    <i class="fab fa-whatsapp"></i> Kirim WhatsApp
                </button>
            `;
        } else {
            teleponCol.textContent = telp || '-';
        }
    }

    attachStatusChangeListeners();
    attachWaButtonListeners(); // Penting agar tombol baru aktif
}

function attachWaButtonListeners() {
    document.querySelectorAll('.open-wa-swal').forEach(button => {
        button.addEventListener('click', function () {
            const phone = this.getAttribute('data-phone');
            const nama = this.getAttribute('data-nama');

            const isLocalhost = location.hostname === 'localhost' || location.hostname === '127.0.0.1';
            const linkUjian = isLocalhost 
                ? 'http://localhost/Albarkah_katimaha/pages/tes/tes.php'
                : 'https://albarkah.com/pages/tes/tes.php';

            Swal.fire({
                title: 'Mau kirim pesan apa?',
                input: 'select',
                inputOptions: {
                    'link_tes': 'Kirim Link Tes',
                    'dokumen_tidak_lengkap': 'Dokumen Tidak Lengkap',
                    'tidak_perlu_tes': 'Tidak Perlu Tes'
                },
                inputPlaceholder: 'Pilih jenis pesan',
                showCancelButton: true,
                confirmButtonText: 'Lanjut',
                cancelButtonText: 'Batal',
                inputValidator: value => !value && 'Pilih salah satu jenis pesan.'
            }).then(firstResult => {
                if (!firstResult.isConfirmed) return;

                let pesan = '';
                const tipePesan = firstResult.value;

                if (tipePesan === 'link_tes') {
                    pesan = `Assalamu’alaikum. Kepada orangtua/wali dari ${nama},\n\nSilakan kunjungi link berikut untuk mengikuti tes online:\n${linkUjian}\n\nMohon mengakses sebelum tanggal 20. Terima kasih.`;
                } else if (tipePesan === 'dokumen_tidak_lengkap') {
                    pesan = `Assalamu’alaikum. Kepada orangtua/wali dari ${nama},\n\nKami menemukan beberapa dokumen yang belum lengkap. Silakan kirimkan dokumen tersebut melalui WhatsApp ini. Terima kasih.`;
                } else if (tipePesan === 'tidak_perlu_tes') {
                    pesan = `Assalamu’alaikum. Kepada orangtua/wali dari ${nama},\n\nKami informasikan bahwa ananda tidak perlu mengikuti tes karena:\n- Jenjang TK tidak memerlukan tes\nATAU\n- Siswa pindahan tidak perlu tes masuk.\n\nTerima kasih.`;
                }

                Swal.fire({
                    title: 'Periksa & Edit Pesan',
                    html: `
                        <p style="margin-bottom: 8px; font-size: 14px; color: #555;">
                        <i class="fa-solid fa-circle-info" style="margin-right: 6px; color: #007bff;"></i>
                        <i>Silakan baca pesan terlebih dahulu, atau ganti teksnya jika ada yang ingin diganti sebelum dikirim ke nomor WhatsApp calon siswa.</i>
                        </p>
                        <textarea id="wa-message" class="swal2-textarea" rows="7">${pesan}</textarea>
                    `,
                    confirmButtonText: 'Kirim',
                    showCancelButton: true,
                    preConfirm: () => {
                        return document.getElementById('wa-message').value.trim();
                    }
                }).then(secondResult => {
                    if (!secondResult.isConfirmed) return;

                    const finalMessage = secondResult.value;

                    fetch('send_wa_twilio.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                        body: `phone=${encodeURIComponent(phone)}&message=${encodeURIComponent(finalMessage)}`
                    })
                    .then(res => res.json())
                    .then(data => {
                        if (data.status === true) {
                            Swal.fire('Terkirim!', 'Pesan berhasil dikirim via WhatsApp.', 'success');
                        } else {
                            Swal.fire('Gagal!', 'Pesan gagal dikirim: ' + (data.message || 'Tidak diketahui'), 'error');
                        }
                    })
                    .catch(error => {
                        console.error(error);
                        Swal.fire('Error', 'Terjadi kesalahan saat mengirim pesan.', 'error');
                    });
                });
            });
        });
    });
}
</script>





<script>
    function downloadData() {
        Swal.fire({
            title: 'Pilih Jenjang Pendidikan',
            input: 'select',
            inputOptions: {
                'TK': 'TK',
                'SD': 'SD',
                'SMP': 'SMP'
            },
            inputPlaceholder: 'Pilih Jenjang',
            showCancelButton: true,
            confirmButtonText: 'Download',
            cancelButtonText: 'Batal',
            preConfirm: (selectedJenjang) => {
                if (!selectedJenjang) {
                    Swal.showValidationMessage('Pilih jenjang pendidikan');
                }
                return selectedJenjang;
            }
        }).then((result) => {
            if (result.isConfirmed) {
                // Kalau user klik Download, kita akan panggil backend dengan parameter jenjang
                window.location.href = `../logic/download.php?jenjang=${result.value}`;
            }
        });
    }
</script>



<script>
    function confirmDeleteAll() {
        // SweetAlert pertama untuk memilih jenjang pendidikan
        Swal.fire({
            title: 'Pilih Jenjang Pendidikan',
            input: 'select',
            inputOptions: {
                'TK': 'TK',
                'SD': 'SD',
                'SMP': 'SMP'
            },
            inputPlaceholder: 'Pilih Jenjang Pendidikan',
            showCancelButton: true,
            confirmButtonText: 'Lanjut',
            cancelButtonText: 'Batal',
            inputValidator: (value) => {
                return new Promise((resolve) => {
                    if (value) {
                        resolve();
                    } else {
                        resolve('Harap pilih jenjang pendidikan!');
                    }
                });
            }
        }).then((result) => {
            if (result.isConfirmed) {
                const selectedOption = result.value;

                // Menampilkan SweetAlert kedua untuk konfirmasi penghapusan data
                Swal.fire({
                    icon: 'warning',
                    title: `Apakah Anda yakin ingin menghapus semua data pendaftaran anak ${selectedOption}?`,
                    text: 'Tindakan ini tidak dapat dibatalkan!',
                    showCancelButton: true,
                    confirmButtonText: 'Ya, Hapus!',
                    cancelButtonText: 'Batal',
                    reverseButtons: true
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Redirect ke script hapus_data_all.php dengan parameter jenjang pendidikan
                        window.location.href = `../logic/hapus_data_all.php?jenjang_pendidikan=${selectedOption}`;
                    }
                });
            }
        });
    }
</script>

<script>
    function confirmDelete(id) {
        // Tampilkan konfirmasi SweetAlert sebelum menghapus data
        Swal.fire({
            icon: 'warning',
            title: 'Apakah Anda yakin?',
            text: 'Data ini akan dihapus secara permanen!',
            showCancelButton: true,
            confirmButtonText: 'Ya, Hapus!',
            cancelButtonText: 'Batal',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                // Jika pengguna menekan "Ya, Hapus!", arahkan ke hapus_data.php
                window.location.href = 'hapus_data.php?id=' + id;
            }
        });
    }
</script>

<?php
if (isset($_GET['status'])) {
    $status = $_GET['status'];
    echo "<script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>";
    echo "<script>
        document.addEventListener('DOMContentLoaded', function() {";
    if ($status == 'success') {
        echo "Swal.fire({
            icon: 'success',
            title: 'Data Berhasil Dihapus!',
            text: 'Data siswa telah berhasil dihapus.',
            confirmButtonText: 'OK'
        }).then(() => {
            window.history.replaceState(null, null, window.location.pathname);
        });";
    } elseif ($status == 'error') {
        echo "Swal.fire({
            icon: 'error',
            title: 'Gagal Menghapus Data!',
            text: 'Terdapat kesalahan saat menghapus data.',
            confirmButtonText: 'OK'
        }).then(() => {
            window.history.replaceState(null, null, window.location.pathname);
        });";
    }
    echo "});
    </script>";
}
?>



<script>
    // Tangkap event klik pada tombol logout
    document.getElementById('logout-link').addEventListener('click', function(event) {
        event.preventDefault(); // Mencegah link agar tidak langsung menuju logout.php

        // Tampilkan SweetAlert konfirmasi logout
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Anda akan keluar dari akun ini!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya, Logout!',
            cancelButtonText: 'Tidak, Tetap di sini!',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                // Jika user memilih 'Ya, Logout!', redirect ke logout.php
                window.location.href = '../logic/logout.php';
            }
        });
    });
</script>

</body>
</html>