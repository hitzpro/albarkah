<?php
include('../config/db.php');

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    $delete_query = "DELETE FROM siswa WHERE id = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param('i', $id);

    if ($stmt->execute()) {
        // Redirect ke manajemen_siswa.php dengan pesan sukses
        header("Location: manajemen_siswa.php?status=success");
    } else {
        // Redirect ke manajemen_siswa.php dengan pesan error
        header("Location: manajemen_siswa.php?status=error");
    }
} else {
    // Redirect jika tidak ada ID
    header("Location: manajemen_siswa.php");
}

$conn->close();
exit();
?>
