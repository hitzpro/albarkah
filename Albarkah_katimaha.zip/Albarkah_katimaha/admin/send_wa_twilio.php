<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $toPhone = $_POST['phone'] ?? '';
    $messageText = $_POST['message'] ?? '';

    $apiKey = 'vae3d99GvtSFi7lLykIT6RpRQRk99DjnwN8MCBAeHXplSWjfiplm7Ne';
    $wablasUrl = "https://bdg.wablas.com/api/v2/send-message";

    // Inilah bagian penting: 'data' harus array
    $payload = [
        'data' => [
            [
                'phone' => $toPhone,
                'message' => $messageText
            ]
        ]
    ];

    $curl = curl_init();
    curl_setopt_array($curl, [
        CURLOPT_URL => $wablasUrl,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_CUSTOMREQUEST => 'POST',
        CURLOPT_POSTFIELDS => json_encode($payload),
        CURLOPT_HTTPHEADER => [
            "Authorization: $apiKey",
            'Content-Type: application/json',
            'secret: ATESnwzF' // tambahkan ini
        ]
    ]);

    $response = curl_exec($curl);
    $err = curl_error($curl);
    curl_close($curl);

    header('Content-Type: application/json');

    if ($err) {
        file_put_contents("log_wa.txt", "CURL ERROR: $err\n", FILE_APPEND);
        echo json_encode(["success" => false, "error" => $err]);
    } else {
        file_put_contents("log_wa.txt", "WABLAS RESPONSE: $response\n", FILE_APPEND);
        echo $response;
    }
}
?>
