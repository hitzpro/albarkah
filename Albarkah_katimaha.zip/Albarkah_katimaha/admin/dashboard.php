<?php
// Memasukkan koneksi database
include('../config/db.php');



// Mengambil jumlah seluruh pendaftar
$query_total = "SELECT COUNT(*) AS total FROM siswa";
$result_total = $conn->query($query_total);
$total_pendaftar = $result_total->fetch_assoc()['total'];

// Mengambil jumlah pendaftar TK
$query_tk = "SELECT COUNT(*) AS tk FROM siswa WHERE jenjang_pendidikan = 'TK'";
$result_tk = $conn->query($query_tk);
$tk_count = $result_tk->fetch_assoc()['tk'];

// Mengambil jumlah pendaftar SD
$query_sd = "SELECT COUNT(*) AS sd FROM siswa WHERE jenjang_pendidikan = 'SD'";
$result_sd = $conn->query($query_sd);
$sd_count = $result_sd->fetch_assoc()['sd'];

// Mengambil jumlah pendaftar SMP
$query_smp = "SELECT COUNT(*) AS smp FROM siswa WHERE jenjang_pendidikan = 'SMP'";
$result_smp = $conn->query($query_smp);
$smp_count = $result_smp->fetch_assoc()['smp'];


$query = "SELECT nama_lengkap, jenis_kelamin, jenjang_pendidikan FROM siswa ORDER BY id DESC LIMIT 10";
$result = $conn->query($query);



?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../assets/css/dashboard.css">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Abhaya+Libre' rel='stylesheet'>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo">
            <!-- Logo placeholder -->
            <img src="../images/logo.png" alt="Logo">
        </div>
        <ul class="sidebar-menu">
    <li>
        <a href="dashboard.php"><img src="../images/dashboard.png" alt="Dashboard">
            <span>Dashboard</span>
        </a>
    </li>
    <li>
        <a href="manajemen_siswa.php"><img src="../images/manajemen.png" alt="Manajemen Siswa">
            <span>Manajemen Siswa</span>
        </a>
    </li>
    <li>
        <a href="tes_murid.php"><img src="../images/tes.png" alt="Tes Murid">
            <span>Tes Murid</span>
        </a>
    </li>
    <li>
        <a href="#" id="logout-link"><img src="../images/logout.png" alt="Keluar">
            <span>Keluar</span>
        </a>
    </li>
</ul>

        <div class="datetime" id="datetime">
            <!-- DateTime will be inserted here by JavaScript -->
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Welcome Section -->
        <div class="welcome-section">
            <img src="../images/user.png" alt="School Logo">
            <div class="welcome-text">
                <h1>Selamat Datang, Admin</h1>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla elementum malesuada elit quis hendrerit. In hac habitasse platea dictumst. Vivamus elementum elit bibendum sollicitudin tempus.</p>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="stats-container">
            <div class="stat-card">
                <h3>Total Pendaftar</h3>
                <div class="number" id="total-pendaftar"><?php echo $total_pendaftar; ?></div>
            </div>
            <div class="stat-card">
                <h3>TK</h3>
                <div class="number" id="tk-count"><?php echo $tk_count; ?></div>
            </div>
            <div class="stat-card">
                <h3>SD</h3>
                <div class="number" id="sd-count"><?php echo $sd_count; ?></div>
            </div>
            <div class="stat-card">
                <h3>SMP</h3>
                <div class="number" id="smp-count"><?php echo $smp_count; ?></div>
            </div>
        </div>

        <!-- Table -->
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama Lengkap</th>
                        <th>Jenis Kelamin</th>
                        <th>Jenjang</th>
                    </tr>
                </thead>
                <tbody id="student-table-body">
                    <?php
                    // Memulai nomor urut
                    $no = 1;

                    // Perulangan untuk menampilkan data
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            // Menampilkan data dalam baris tabel
                            echo "<tr>
                                    <td>{$no}</td>
                                    <td>{$row['nama_lengkap']}</td>
                                    <td>{$row['jenis_kelamin']}</td>
                                    <td>{$row['jenjang_pendidikan']}</td>
                                </tr>";
                            // Increment nomor urut
                            $no++;
                        }
                    } else {
                        echo "<tr><td colspan='4'>Tidak ada data siswa</td></tr>";
                    }

                    // Menutup koneksi
                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
        <button class="action-button">Kelola Data Siswa</button>
    </div>

    <script>
        // Function to update date and time
        function updateDateTime() {
            const now = new Date();
            const options = {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit',
                hour12: false
            };
            const dateTimeStr = now.toLocaleDateString('id-ID', options);
            document.getElementById('datetime').textContent = dateTimeStr;
        }

        // Update immediately and then every second
        updateDateTime();
        setInterval(updateDateTime, 1000);
    </script>


<script>
// Menambahkan kelas active pada elemen <li> yang diklik
const items = document.querySelectorAll('.sidebar-menu li');
items.forEach(item => {
    item.addEventListener('click', () => {
        items.forEach(i => i.classList.remove('active')); // Menghapus kelas active dari semua <li>
        item.classList.add('active'); // Menambahkan kelas active pada <li> yang diklik
    });
});

// Menambahkan kelas active pada elemen pertama saat halaman dimuat
window.addEventListener('load', () => {
    items[0].classList.add('active'); // Menambahkan kelas active pada elemen pertama
});

</script>




<!-- script logout -->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>
    // Tangkap event klik pada tombol logout
    document.getElementById('logout-link').addEventListener('click', function(event) {
        event.preventDefault(); // Mencegah link agar tidak langsung menuju logout.php

        // Tampilkan SweetAlert konfirmasi logout
        Swal.fire({
            title: 'Apakah Anda yakin?',
            text: "Anda akan keluar dari akun ini!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Ya, Logout!',
            cancelButtonText: 'Tidak, Tetap di sini!',
            reverseButtons: true
        }).then((result) => {
            if (result.isConfirmed) {
                // Jika user memilih 'Ya, Logout!', redirect ke logout.php
                window.location.href = '../logic/logout.php';
            }
        });
    });
</script>

</body>
</html>