<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Form Pendaftaran Siswa</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .form-section {
            display: none;
        }
        .active {
            display: block;
        }
        .question {
            margin-bottom: 20px;
        }
        .file-input-container {
            margin-bottom: 20px;
        }
        .error {
            color: red;
            font-size: 0.85rem;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white">
                        <h3 class="mb-0">Form Pendaftaran Siswa</h3>
                    </div>
                    <div class="card-body">
                        <form id="registrationForm" action="process.php" method="POST" enctype="multipart/form-data">
                            <!-- Data Umum -->
                            <div class="mb-3">
                                <label for="nama" class="form-label">Nama Lengkap</label>
                                <input type="text" class="form-control" id="nama" name="nama" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="jenjang" class="form-label">Pilih Jenjang</label>
                                <select class="form-select" id="jenjang" name="jenjang" required>
                                    <option value="">-- Pilih Jenjang --</option>
                                    <option value="SDIT">SDIT</option>
                                    <option value="SMPIT">SMPIT</option>
                                </select>
                            </div>
                            
                            <!-- Bagian SDIT -->
                            <div id="sditSection" class="form-section">
                                <div class="mb-4 p-3 bg-light rounded">
                                    <h4 class="mb-3">Tes Membaca</h4>
                                    <div class="mb-3">
                                        <h5>Bacaan:</h5>
                                        <div class="p-3 border rounded">
                                            <p>"Indonesia adalah negara kepulauan terbesar di dunia. Memiliki lebih dari 17.000 pulau dengan beragam suku, bahasa, dan budaya. Keanekaragaman ini menjadi kekayaan bangsa yang harus kita jaga dan lestarikan. Bersama-sama kita membangun Indonesia menjadi negara yang maju dan sejahtera."</p>
                                        </div>
                                    </div>
                                    
                                    <div class="file-input-container">
                                        <label for="videoMembaca" class="form-label">Upload Video Membaca</label>
                                        <input type="file" class="form-control" id="videoMembaca" name="videoMembaca" accept=".mp4,.mov">
                                        <div class="error" id="videoMembacaError"></div>
                                        <small class="text-muted">Format: MP4, MOV. Maksimal 30MB</small>
                                    </div>
                                </div>
                                
                                <div class="mb-4">
                                    <div class="file-input-container">
                                        <label for="fotoTulisan" class="form-label">Upload Foto Tulisan Tangan</label>
                                        <input type="file" class="form-control" id="fotoTulisan" name="fotoTulisan" accept=".jpg,.jpeg,.png">
                                        <div class="error" id="fotoTulisanError"></div>
                                        <small class="text-muted">Format: JPG, JPEG, PNG. Maksimal 30MB</small>
                                    </div>
                                </div>
                                
                                <div class="mb-4">
                                    <h4 class="mb-3">Soal Matematika</h4>
                                    <div id="sditQuestions">
                                        <!-- Soal akan dimuat dari database melalui AJAX -->
                                        <div class="text-center py-4">
                                            <div class="spinner-border text-primary" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                            <p class="mt-2">Memuat soal...</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Bagian SMPIT -->
                            <div id="smpitSection" class="form-section">
                                <div class="mb-4">
                                    <div class="file-input-container">
                                        <label for="videoQuran" class="form-label">Upload Video Membaca Al-Qur'an</label>
                                        <input type="file" class="form-control" id="videoQuran" name="videoQuran" accept=".mp4,.mov">
                                        <div class="error" id="videoQuranError"></div>
                                        <small class="text-muted">Format: MP4, MOV. Maksimal 30MB</small>
                                    </div>
                                </div>
                                
                                <div class="mb-4">
                                    <h4 class="mb-3">Soal Matematika & Wawasan Islam</h4>
                                    <div id="smpitQuestions">
                                        <!-- Soal akan dimuat dari database melalui AJAX -->
                                        <div class="text-center py-4">
                                            <div class="spinner-border text-primary" role="status">
                                                <span class="visually-hidden">Loading...</span>
                                            </div>
                                            <p class="mt-2">Memuat soal...</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <!-- Button Submit -->
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary btn-lg" id="submitBtn">Submit Pendaftaran</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS & jQuery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    
    <script>
        $(document).ready(function() {
            // Handler untuk perubahan jenjang
            $('#jenjang').on('change', function() {
                const jenjang = $(this).val();
                
                // Sembunyikan semua bagian form
                $('.form-section').removeClass('active');
                
                // Tampilkan bagian yang sesuai
                if (jenjang === 'SDIT') {
                    $('#sditSection').addClass('active');
                    loadQuestions('SDIT', 'sditQuestions');
                } else if (jenjang === 'SMPIT') {
                    $('#smpitSection').addClass('active');
                    loadQuestions('SMPIT', 'smpitQuestions');
                }
            });
            
            // Fungsi untuk memuat soal dari database
            function loadQuestions(jenjang, containerId) {
                $.ajax({
                    url: 'get_questions.php',
                    type: 'GET',
                    data: { jenjang: jenjang },
                    success: function(response) {
                        $(`#${containerId}`).html(response);
                    },
                    error: function() {
                        $(`#${containerId}`).html('<div class="alert alert-danger">Gagal memuat soal. Silakan coba lagi.</div>');
                    }
                });
            }
            
            // Validasi file upload
            function validateFile(fileInput, errorElement, maxSize = 30) {
                const file = fileInput.files[0];
                if (!file) return true;
                
                // Convert maxSize from MB to bytes
                const maxBytes = maxSize * 1024 * 1024;
                
                if (file.size > maxBytes) {
                    $(errorElement).text(`Ukuran file terlalu besar. Maksimal ${maxSize}MB.`);
                    return false;
                }
                
                // Clear error if everything is okay
                $(errorElement).text('');
                return true;
            }
            
            // Validasi saat file di-upload
            $('#videoMembaca').on('change', function() {
                validateFile(this, '#videoMembacaError');
            });
            
            $('#fotoTulisan').on('change', function() {
                validateFile(this, '#fotoTulisanError');
            });
            
            $('#videoQuran').on('change', function() {
                validateFile(this, '#videoQuranError');
            });
            
            // Form submission
            $('#registrationForm').on('submit', function(e) {
                let valid = true;
                
                // Validasi file berdasarkan jenjang yang dipilih
                const jenjang = $('#jenjang').val();
                
                if (jenjang === 'SDIT') {
                    if (!validateFile(document.getElementById('videoMembaca'), '#videoMembacaError')) valid = false;
                    if (!validateFile(document.getElementById('fotoTulisan'), '#fotoTulisanError')) valid = false;
                } else if (jenjang === 'SMPIT') {
                    if (!validateFile(document.getElementById('videoQuran'), '#videoQuranError')) valid = false;
                }
                
                if (!valid) {
                    e.preventDefault();
                    alert('Mohon perbaiki kesalahan pada form sebelum mengirimkan.');
                }
            });
        });
    </script>
</body>
</html>