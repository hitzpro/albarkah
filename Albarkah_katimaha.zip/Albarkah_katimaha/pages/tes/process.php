<?php
// Database connection
$host = "localhost";
$username = "root"; // Change this to your database username
$password = ""; // Change this to your database password
$database = "db_tes_masuk";

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Function to handle file upload
function handle_file_upload($file, $target_directory) {
    // Create directory if it doesn't exist
    if (!is_dir($target_directory)) {
        mkdir($target_directory, 0777, true);
    }
    
    $file_name = basename($file["name"]);
    $file_extension = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    $unique_file_name = uniqid() . '.' . $file_extension;
    $target_file = $target_directory . $unique_file_name;
    
    // Check file size (30MB max)
    if ($file["size"] > 30000000) {
        return false;
    }
    
    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        return $unique_file_name;
    } else {
        return false;
    }
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get basic information
    $nama = sanitize_input($_POST["nama"]);
    $jenjang = sanitize_input($_POST["jenjang"]);
    $tanggal_daftar = date("Y-m-d H:i:s");
    
    // Initialize file paths
    $video_membaca = null;
    $foto_tulisan = null;
    $video_quran = null;
    
    // Handle file uploads based on jenjang
    if ($jenjang == "SDIT") {
        // Handle video membaca upload
        if (isset($_FILES["videoMembaca"]) && $_FILES["videoMembaca"]["error"] == 0) {
            $video_membaca = handle_file_upload($_FILES["videoMembaca"], "uploads/video_membaca/");
            if (!$video_membaca) {
                die("Error uploading video membaca");
            }
        }
        
        // Handle foto tulisan upload
        if (isset($_FILES["fotoTulisan"]) && $_FILES["fotoTulisan"]["error"] == 0) {
            $foto_tulisan = handle_file_upload($_FILES["fotoTulisan"], "uploads/foto_tulisan/");
            if (!$foto_tulisan) {
                die("Error uploading foto tulisan");
            }
        }
    } elseif ($jenjang == "SMPIT") {
        // Handle video quran upload
        if (isset($_FILES["videoQuran"]) && $_FILES["videoQuran"]["error"] == 0) {
            $video_quran = handle_file_upload($_FILES["videoQuran"], "uploads/video_quran/");
            if (!$video_quran) {
                die("Error uploading video quran");
            }
        }
    }
    
    // Insert into siswa table
    $stmt = $conn->prepare("INSERT INTO siswa (nama, jenjang, video_membaca, foto_tulisan, video_quran, tanggal_daftar) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $nama, $jenjang, $video_membaca, $foto_tulisan, $video_quran, $tanggal_daftar);
    
    if ($stmt->execute()) {
        $siswa_id = $conn->insert_id;
        
        // Initialize counters for scoring
        $total_benar = 0;
        $total_soal = 0;
        
        // Get all the answers from the form submission (jawaban_1, jawaban_2, etc.)
        foreach ($_POST as $key => $value) {
            if (strpos($key, "jawaban_") === 0) {
                $soal_id = substr($key, 8); // Remove "jawaban_" to get the ID
                $jawaban = sanitize_input($value);
                
                // Save student answer to jawaban_siswa table
                $stmt = $conn->prepare("INSERT INTO jawaban_siswa (siswa_id, soal_id, jawaban) VALUES (?, ?, ?)");
                $stmt->bind_param("iis", $siswa_id, $soal_id, $jawaban);
                $stmt->execute();
                
                // Fetch the correct answer from soal table
                $stmt = $conn->prepare("SELECT kunci_jawaban FROM soal WHERE id = ?");
                $stmt->bind_param("i", $soal_id);
                $stmt->execute();
                $result = $stmt->get_result();
                
                if ($row = $result->fetch_assoc()) {
                    $total_soal++;
                    
                    // Compare student's answer with the correct answer
                    if ($jawaban == $row["kunci_jawaban"]) {
                        $total_benar++;
                    }
                }
            }
        }
        
        // Calculate score (0-100)
        $nilai = 0;
        if ($total_soal > 0) {
            $nilai = ($total_benar / $total_soal) * 100;
        }
        
        // Save the score to nilai table
        $stmt = $conn->prepare("INSERT INTO nilai (siswa_id, nilai, total_benar, total_soal) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("idii", $siswa_id, $nilai, $total_benar, $total_soal);
        
        if ($stmt->execute()) {
            // Redirect to a success page with the results
            echo("<script>alert('berhasil menjawab')</script>");
            header("Location: ../index.php");
            exit();
        } else {
            echo "Error saving score: " . $stmt->error;
        }
    } else {
        echo "Error saving student data: " . $stmt->error;
    }
    
    $stmt->close();
    $conn->close();
} else {
    // Not a POST request, redirect to form
    header("Location: tes.php");
    exit();
}
?>