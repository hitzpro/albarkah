<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_tes_masuk";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}

$jenjang = $_GET['jenjang'] ?? '';

if ($jenjang !== 'SDIT' && $jenjang !== 'SMPIT') {
    echo "<div class='alert alert-warning'>Jenjang tidak valid.</div>";
    exit;
}

$sql = "SELECT * FROM soal WHERE jenjang = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $jenjang);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $no = 1;
    while ($row = $result->fetch_assoc()) {
        echo "<div class='question'>";
        echo "<label><strong>Soal $no:</strong> {$row['pertanyaan']}</label>";
        echo "<div class='form-check'><input class='form-check-input' type='radio' name='jawaban_{$row['id']}' value='A'> A. {$row['opsi_a']}</div>";
        echo "<div class='form-check'><input class='form-check-input' type='radio' name='jawaban_{$row['id']}' value='B'> B. {$row['opsi_b']}</div>";
        echo "<div class='form-check'><input class='form-check-input' type='radio' name='jawaban_{$row['id']}' value='C'> C. {$row['opsi_c']}</div>";
        echo "<div class='form-check'><input class='form-check-input' type='radio' name='jawaban_{$row['id']}' value='D'> D. {$row['opsi_d']}</div>";
        echo "</div>";
        $no++;
    }
} else {
    echo "<div class='alert alert-info'>Belum ada soal untuk jenjang ini.</div>";
}

$stmt->close();
$conn->close();
?>
