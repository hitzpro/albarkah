<?php
include('../includes/navbar.php');
// include('../config/db.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../assets/css/index.css">
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <link href='https://fonts.googleapis.com/css?family=Abhaya+Libre' rel='stylesheet'>
    <!-- CSS Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- JS Bootstrap 5 (termasuk Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/footer.css">

    <style>
        .beranda{
            border-bottom: 2px solid #6C757D;
        }
    </style>
</head>
<body>
    
<header class="container-fluid bg-opacity-25 py-5">
    <div class="container">
        <div class="row align-items-center flex-md-row flex-column-reverse">
            <!-- Content -->
            <div class="col-md-6 text-md-start text-center content d-flex flex-column gap-2 tombol" >
                <h1 class="fw-bold">Selamat Datang Di Yayasan Al Barkah Katimaha</h1>
                <p class="text-muted">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Labore nihil necessitatibus vel laborum quisquam cum!
                    Lorem ipsum dolor sit amet consectetur adipisicing elit.
                </p>
                <div class="d-flex gap-3 justify-content-md-start justify-content-center">
                    <a href="#" class="btn btn-primary">Daftar Sekarang</a>
                    <a href="#" class="btn btn-outline-primary">Lihat Info Pendaftaran</a>
                </div>
            </div>

            <!-- Image -->
            <div class="col-md-6 text-center">
                <img src="../images/header 1.png" alt="Header Image" class="img-fluid">
            </div>
        </div>
    </div>
</header>


<div class="custom-container">
    <div class="custom-inner-container">
        <div class="custom-section">
            <!-- Image -->
            <div class="custom-image" id="bgGedung">
                <img src="../images/BG_gedung.jpg" alt="Header Image">
            </div>
            <!-- Content -->
            <div class="custom-content">
                <h2 class="custom-title">Layanan Pendidikan Untuk Anak</h2>
                <p class="custom-text">
                    Menyediakan Lembaga Pendidikan Islam Jenjang TK, SD, dan SMP
                    Pembelajaran sudah menggunakan kurikulum Merdeka
                    Kegiatan Ekstrakurikuler untuk setiap anak
                    Guru-guru yang sudah berpengalaman dalam mengajar
                </p>
                <div class="custom-button-container tombol">
                    <a href="#" class="btn btn-outline-primary">Lihat Selengkapnya</a>
                </div>
            </div>
        </div>
    </div>
</div>



<section class="informasi">
    <h2><strong>Pendaftaran</strong></h2>
    <!-- Versi Grid (Desktop) -->
    <div class="kartu">
        <div class="card-tk">
            <div class="judul">
                <h3><strong>TK Al Barkah</strong></h3>
            </div>
            <div class="konten">
                <p><strong>Program Unggulan</strong></p>
                <hr>
                <ul>
                    <li>Praktik Manasik Haji</li>
                    <li>Praktik Sholat</li>
                    <li>Hafalan Asmaul Husna</li>
                    <li>Hafalan surat Pendek</li>
                    <li>Hafalan Hadis Pendek</li>
                    <li>Outing Class</li>
                    <li>Porseni Tingkat Kecamatan</li>
                </ul>
                <a href="daftarTK.php">Daftar Sekarang</a>
            </div>
        </div>

        <div class="card-sd">
            <div class="judul">
                <h3><strong>SD Al Barkah</strong></h3>
            </div>
            <div class="konten">
                <p><strong>Program Unggulan</strong></p>
                <hr>
                <ul>
                    <li>Praktik Manasik Haji</li>
                    <li>Praktik Sholat</li>
                    <li>Hafalan Asmaul Husna</li>
                    <li>Hafalan surat Pendek</li>
                    <li>Hafalan Hadis Pendek</li>
                    <li>Outing Class</li>
                    <li>Porseni Tingkat Kecamatan</li>
                </ul>
                <a href="daftarSD.php">Daftar Sekarang</a>
            </div>
        </div>

        <div class="card-smp">
            <div class="judul">
                <h3><strong>SMP Al Barkah</strong></h3>
            </div>
            <div class="konten">
                <p><strong>Program Unggulan</strong></p>
                <hr>
                <ul>
                    <li>Praktik Manasik Haji</li>
                    <li>Praktik Sholat</li>
                    <li>Hafalan Asmaul Husna</li>
                    <li>Hafalan surat Pendek</li>
                    <li>Hafalan Hadis Pendek</li>
                    <li>Outing Class</li>
                    <li>Porseni Tingkat Kecamatan</li>
                </ul>
                <a href="daftarSMP.php">Daftar Sekarang</a>
            </div>
        </div>
    </div>

    <div class="karousel">
    <button class="karousel-btn prev">&#10094;</button>
    <div class="karousel-track">
        <div class="karousel-item card-tk">
            <div class="judul">
                <h3><strong>TK Al Barkah</strong></h3>
            </div>
            <div class="konten">
                <p><strong>Program Unggulan</strong></p>
                <hr>
                <ul>
                    <li>Praktik Manasik Haji</li>
                    <li>Praktik Sholat</li>
                    <li>Hafalan Asmaul Husna</li>
                    <li>Hafalan surat Pendek</li>
                    <li>Hafalan Hadis Pendek</li>
                    <li>Outing Class</li>
                    <li>Porseni Tingkat Kecamatan</li>
                </ul>
                <a href="#">Daftar Sekarang</a>
            </div>
        </div>

        <div class="karousel-item card-sd">
            <div class="judul">
                <h3><strong>SD Al Barkah</strong></h3>
            </div>
            <div class="konten">
                <p><strong>Program Unggulan</strong></p>
                <hr>
                <ul>
                    <li>Praktik Manasik Haji</li>
                    <li>Praktik Sholat</li>
                    <li>Hafalan Asmaul Husna</li>
                    <li>Hafalan surat Pendek</li>
                    <li>Hafalan Hadis Pendek</li>
                    <li>Outing Class</li>
                    <li>Porseni Tingkat Kecamatan</li>
                </ul>
                <a href="#">Daftar Sekarang</a>
            </div>
        </div>

        <div class="karousel-item card-smp">
            <div class="judul">
                <h3><strong>SMP Al Barkah</strong></h3>
            </div>
            <div class="konten">
                <p><strong>Program Unggulan</strong></p>
                <hr>
                <ul>
                    <li>Praktik Manasik Haji</li>
                    <li>Praktik Sholat</li>
                    <li>Hafalan Asmaul Husna</li>
                    <li>Hafalan surat Pendek</li>
                    <li>Hafalan Hadis Pendek</li>
                    <li>Outing Class</li>
                    <li>Porseni Tingkat Kecamatan</li>
                </ul>
                <a href="#">Daftar Sekarang</a>
            </div>
        </div>
    </div>
    <button class="karousel-btn next">&#10095;</button>
    <!-- Indikator Titik -->
    <div class="karousel-indicator">
        <span class="indicator-dot active"></span>
        <span class="indicator-dot"></span>
        <span class="indicator-dot"></span>
    </div>
</div>



</section>



<!-- Section Kepala Sekolah (Normal) -->
<div class="container-fluid bg-opacity-25 py-5" id="kepalaSekolahSection">
    <div class="container">
        <div class="row align-items-center flex-column-reverse flex-md-row">
            <!-- Content -->
            <div class="col-md-6 text-start content d-flex flex-column gap-3">
                <h1 class="fw-bold">Kepala Sekolah Tk Al Barkah Yusufiyah</h1>
                <p class="text-muted">
                    Menyediakan Lembaga Pendidikan Islam Jenjang TK, SD, dan SMP
                    Pembelajaran sudah menggunakan kurikulum Merdeka
                    Kegiatan Ekstrakurikuler untuk setiap anak
                    Guru-guru yang sudah berpengalaman dalam mengajar
                </p>
                <div class="d-flex gap-3 justify-content-start tombol">
                    <a href="#" class="btn btn-outline-primary">Lihat Selengkapnya</a>
                </div>
            </div>
            <!-- Image -->
            <div class="col-md-6 text-center">
                <img src="../images/umi-eliyanah.png" alt="Header Image" class="img-fluid">
            </div>
        </div>
    </div>
</div>

<div class="container-fluid bg-opacity-25 py-5" id="kepalaSekolahSection">
    <div class="container">
        <div class="row align-items-center flex-column-reverse flex-md-row">
            <!-- Image -->
            <div class="col-md-6 text-center">
                <img src="../images/abi-yusuf.png" alt="Header Image" class="img-fluid">
            </div>
            <!-- Content -->
            <div class="col-md-6 text-end content d-flex flex-column gap-3">
                <h1 class="fw-bold">Kepala Sekolah SDIT Al Barkah</h1>
                <p class="text-muted">
                    Menyediakan Lembaga Pendidikan Islam Jenjang TK, SD, dan SMP
                    Pembelajaran sudah menggunakan kurikulum Merdeka
                    Kegiatan Ekstrakurikuler untuk setiap anak
                    Guru-guru yang sudah berpengalaman dalam mengajar
                </p>
                <div class="d-flex gap-3 justify-content-end tombol">
                    <a href="#" class="btn btn-outline-primary">Lihat Selengkapnya</a>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid bg-opacity-25 py-5" id="kepalaSekolahSection">
    <div class="container">
        <div class="row align-items-center flex-column-reverse flex-md-row kepsek">
            <!-- Content -->
            <div class="col-md-6 text-start content d-flex flex-column gap-3 content">
                <h1 class="fw-bold">Kepala Sekolah SMPIT Al Barkah </h1>
                <p class="text-muted">
                    Menyediakan Lembaga Pendidikan Islam Jenjang TK, SD, dan SMP
                    Pembelajaran sudah menggunakan kurikulum Merdeka
                    Kegiatan Ekstrakurikuler untuk setiap anak
                    Guru-guru yang sudah berpengalaman dalam mengajar
                </p>
                <div class="d-flex gap-3 justify-content-start tombol">
                    <a href="#" class="btn btn-outline-primary">Lihat Selengkapnya</a>
                </div>
            </div>
            <!-- Image -->
            <div class="col-md-6 text-center">
                <img src="../images/ust-andri.png" alt="Header Image" class="img-fluid">
            </div>
        </div>
    </div>
</div>

<!-- Carousel untuk ukuran kecil (Responsif) -->
<div id="kepalaSekolahCarousel" class="carousel slide d-md-none" data-bs-ride="carousel">
    <div class="carousel-inner">
        <div class="carousel-item active">
            <div class="d-flex">
                <div class="carousel-content">
                    <h1 class="fw-bold">Kepala Sekolah Tk Al Barkah Yusufiyah</h1>
                    <p class="text-muted">
                        Menyediakan Lembaga Pendidikan Islam Jenjang TK, SD, dan SMP
                        Pembelajaran sudah menggunakan kurikulum Merdeka
                        Kegiatan Ekstrakurikuler untuk setiap anak
                        Guru-guru yang sudah berpengalaman dalam mengajar
                    </p>
                    <div class="d-flex gap-3 justify-content-start tombol">
                        <a href="#" class="btn btn-outline-primary">Lihat Selengkapnya</a>
                    </div>
                </div>
                <div class="carousel-image">
                    <img src="../images/umi-eliyanah.png" alt="Header Image" class="img-fluid">
                </div>
            </div>
        </div>
        <div class="carousel-item">
            <div class="d-flex">
                <div class="carousel-content">
                    <h1 class="fw-bold">Kepala Sekolah SDIT Al Barkah</h1>
                    <p class="text-muted">
                        Menyediakan Lembaga Pendidikan Islam Jenjang TK, SD, dan SMP
                        Pembelajaran sudah menggunakan kurikulum Merdeka
                        Kegiatan Ekstrakurikuler untuk setiap anak
                        Guru-guru yang sudah berpengalaman dalam mengajar
                    </p>
                    <div class="d-flex gap-3 justify-content-start tombol">
                        <a href="#" class="btn btn-outline-primary">Lihat Selengkapnya</a>
                    </div>
                </div>
                <div class="carousel-image">
                    <img src="../images/abi-yusuf.png" alt="Header Image" class="img-fluid">
                </div>
            </div>
        </div>
        <div class="carousel-item">
            <div class="d-flex">
                <div class="carousel-content">
                    <h1 class="fw-bold">Kepala Sekolah SMPIT Al Barkah</h1>
                    <p class="text-muted">
                        Menyediakan Lembaga Pendidikan Islam Jenjang TK, SD, dan SMP
                        Pembelajaran sudah menggunakan kurikulum Merdeka
                        Kegiatan Ekstrakurikuler untuk setiap anak
                        Guru-guru yang sudah berpengalaman dalam mengajar
                    </p>
                    <div class="d-flex gap-3 justify-content-start tombol">
                        <a href="#" class="btn btn-outline-primary">Lihat Selengkapnya</a>
                    </div>
                </div>
                <div class="carousel-image">
                    <img src="../images/ust-andri.png" alt="Header Image" class="img-fluid">
                </div>
            </div>
        </div>
    </div>
    <button class="carousel-control-prev" type="button" data-bs-target="#kepalaSekolahCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Previous</span>
    </button>
    <button class="carousel-control-next" type="button" data-bs-target="#kepalaSekolahCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon" aria-hidden="true"></span>
        <span class="visually-hidden">Next</span>
    </button>
</div>




<section class="maps">
    <h2>Lokasi kami</h2>
    <iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15865.677699633348!2d107.1768001!3d-6.208279!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e6985087f55f953%3A0x70c37bc7d9059156!2sYayasan%20Al-barkah%20Katimaha%20%2F%20TK-TPA-MDTA-SDIT-SMPIT-PONPES%20AL%20BARKAH%20KATIMAHA!5e0!3m2!1sid!2sid!4v1739192674078!5m2!1sid!2sid"  style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
</section>


<section class="more">
    <div class="more-info">
        <div class="contact1">
                <img src="../images/user.png" alt="">
                <h2>Ust. Zaki Tamimi</h2>
                <div class="telp">
                    <img src="../images/whatsapp.png" alt="">
                    <p>081336889643</p>
                </div>
            </div>


            <div class="contact1">
                <img src="../images/user.png" alt="">
                <h2>Ust. Falhan Dimyathi yusuf</h2>
                <div class="telp">
                    <img src="../images/whatsapp.png" alt="">
                    <p>081336889643</p>
                </div>
            </div>
    </div>

    <div class="sosmed">
        <div class="container">
            <a href="#"><img src="../images/instagram.png" alt=""></a>
        </div>
        <div class="container">
            <a href="#"><img src="../images/tiktok.png" alt=""></a>
        </div>
        <div class="container">
            <a href="#"><img src="../images/youtube.png" alt=""></a>
        </div>
        <div class="container">
            <a href="#"><img src="../images/facebook.png" alt=""></a>
        </div>
    </div>

</section>


<?php include "../includes/footer.php"; ?>

<script>

document.addEventListener('DOMContentLoaded', function () {
    const prevButton = document.querySelector('.karousel-btn.prev');
    const nextButton = document.querySelector('.karousel-btn.next');
    const track = document.querySelector('.karousel-track');
    const items = document.querySelectorAll('.karousel-item');
    const indicators = document.querySelectorAll('.indicator-dot');
    let index = 0;

    const updateCarousel = () => {
        // Update track position
        const itemWidth = items[0].offsetWidth + 20; // Including margin
        track.style.transform = `translateX(-${index * itemWidth}px)`;

        // Update active indicator
        indicators.forEach((dot, i) => {
            dot.classList.toggle('active', i === index);
        });
    };

    // Next button
    nextButton.addEventListener('click', () => {
        index = (index + 1) % items.length;
        updateCarousel();
    });

    // Previous button
    prevButton.addEventListener('click', () => {
        index = (index - 1 + items.length) % items.length;
        updateCarousel();
    });

    // Initial update
    updateCarousel();
});



</script>

</body>
</html>