<?php
include('../includes/navbar.php');
// include('../config/db.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <!-- CSS Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- JS Bootstrap 5 (termasuk Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/footer.css">
    <link rel="stylesheet" href="../assets/css/tentang-kami.css">
    <style>
        .tentang-kami{
            border-bottom: 2px solid #6C757D;

        }
    </style>
</head>
<body>
    
<div class="container2">
        <h1><strong>Tentang Kami</strong></h1>
        
        <div class="about-section">
            <div class="building-image">
                <img src="../images/bg_gedung.jpg" alt="Yayasan Al Barkah Katimaha">
            </div>
            <div class="about-content">
                <h2><strong>Yayasan Al Barkah Katimaha</strong></h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla ultricies urna et ligula facilisis hendrerit. Sed hendrerit elit lorem, a finibus dolor eleifend vitae. Proin vehicula metus id dapibus. Nulla eu tristique metus. Maecenas elementum elit hendrerit vulputate hendrerit. Vivamus elementum elit hendrerit velit mollis tempus. Nulla imperdiet libero sapien. Ut eu gravida metus venenatis leo. Fusce fringilla vehicula urna et dapibus. Nulla eu tristique metus et et finibus felis.</p>
            </div>
        </div>

        <div class="staff-section">
            <h2><strong>Kepala Sekolah</strong></h2>
            <div class="staff-cards">
                <div class="staff-card">
                    <div class="staff-image">
                        <img src="../images/ust.png" alt="Ust. Andri S.Pd">
                    </div>
                    <div class="staff-info">
                        <h3><strong>Ust. Andri S.Pd</strong></h3>
                        <p>Kepala Sekolah SMPT Al Barkah Katimaha</p>
                        <a href="#" class="profile-button">Lihat Profil</a>
                    </div>
                </div>

                <div class="staff-card">
                    <div class="staff-image">
                        <img src="../images/abi.png"" alt="Abi Yusuf S. S.Pd.I">
                    </div>
                    <div class="staff-info">
                        <h3><strong>Abi Yusuf S. S.Pd.I</strong></h3>
                        <p>Kepala Sekolah SMP Al Barkah Katimaha</p>
                        <a href="#" class="profile-button">Lihat Profil</a>
                    </div>
                </div>

                <div class="staff-card">
                    <div class="staff-image">
                        <img src="../images/umi.png"" alt="Umi Elyanah">
                    </div>
                    <div class="staff-info">
                        <h3><strong>Umi Elyanah</strong></h3>
                        <p>Kepala Sekolah TK Al Barkah Katimaha</p>
                        <a href="#" class="profile-button">Lihat Profil</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include "../includes/footer.php"; ?>

</body>
</html>