<?php
include('../includes/navbar.php');
// include('../config/db.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <!-- CSS Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- JS Bootstrap 5 (termasuk Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/footer.css">
    <link rel="stylesheet" href="../assets/css/kontak_kami.css">
    <style>
        .kontak{
            border-bottom: 2px solid #6C757D;

        }
    </style>
</head>
<body>
    
<div class="contact-container">
    <h1>Kontak Kami</h1>
    <div class="contact-content">
        <div class="info-box">
            <div class="contact-details">
                <h3><strong>Informasi Kontak Kami</strong></h3>
                <p>Silahkan Untuk Menghubungi Kami Via Email Atau Bisa Melalui Nomor Yang Tertera Dibawah Ini. Dengan Senang Hati Kami Bisa membantu anda dalam menemukan solusi permasalahan anda terkait yayasan kami.</p>
            </div>
            <div class="contact-entry">
                <i>📱</i>
                <span>Ust Fathan Diruyatul Yusuf</span>
            </div>
            <div class="contact-entry">
                <i>📱</i>
                <span>Ust M. Zaki Tamimi</span>
            </div>
            <div class="contact-entry">
                <i>✉️</i>
                <span>AlbarkahKatimaha@gmail.com</span>
            </div>
            <div class="contact-entry">
                <i>📍</i>
                <span>Jl. Kp Katimaha, Karanganyar, Kec. Karangbahagia, Kabupaten Bekasi, Jawa Barat 17530</span>
            </div>
            <div class="social-media-links">
                <a href="#"><img src="../images/ig.png" alt=""></a>
                <a href="#"><img src="../images/tt.png" alt=""></a>
                <a href="#"><img src="../images/yt.png" alt=""></a>
                <a href="#"><img src="../images/fb.png" alt=""></a>
            </div>
        </div>
        <div class="form-box">
            <h3><strong>Tanya Langsung Lewat Email</strong></h3>
            <form>
                <div class="input-group">
                    <label>Nama</label>
                    <input type="text" placeholder="Masukkan Nama Anda">
                </div>
                <div class="input-group">
                    <label>Email</label>
                    <input type="email" placeholder="Masukkan Email Anda">
                </div>
                <div class="input-group">
                    <label>Judul Pertanyaan</label>
                    <input type="text" placeholder="Masukkan Judul Pertanyaan">
                </div>
                <div class="input-group">
                    <label>Isi Pertanyaan</label>
                    <textarea placeholder="Masukkan Isi Pertanyaan"></textarea>
                </div>
                <div class="button-container">
                    <button type="submit">Kirim Pesan</button>
                    <button type="button" class="help-button">Baca Panduan Sebelum Bertanya</button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php include "../includes/footer.php"; ?>

</body>
</html>