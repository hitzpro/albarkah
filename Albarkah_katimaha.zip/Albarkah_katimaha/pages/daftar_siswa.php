<?php
include('../config/db.php'); // Menyertakan file koneksi database
include('../includes/navbar.php'); // Menyertakan navbar

// Tentukan jumlah data yang akan ditampilkan per halaman
$limit = 10; 

// Ambil halaman saat ini dari URL (default halaman 1)
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Query untuk mengambil data siswa
$query = "SELECT nama_lengkap, jenjang_pendidikan, jenis_kelamin, status FROM siswa LIMIT $limit OFFSET $offset";
$result = $conn->query($query);

// Query untuk menghitung total data
$total_query = "SELECT COUNT(*) FROM siswa";
$total_result = $conn->query($total_query);
$total_data = $total_result->fetch_row()[0];
$total_pages = ceil($total_data / $limit); // Menghitung total halaman

$jenjang = isset($_GET['jenjang']) ? $_GET['jenjang'] : 'TK'; // Default ke 'TK'

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href='https://fonts.googleapis.com/css?family=Poppins' rel='stylesheet'>
    <!-- CSS Bootstrap 5 -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- JS Bootstrap 5 (termasuk Popper.js) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/footer.css">
    <link rel="stylesheet" href="../assets/css/daftar_siswa.css">
    <style>
        /* Tambahkan CSS untuk tabel */
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            font-family:poppins;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: center;
        }

        th {
            background-color: #8A4CE8;
            color:white;
        }

        /* Status dengan teks dalam kapsul */
        .status-pending p {
            background-color: yellow;
            color: black;
            padding: 5px 15px;
            border-radius: 20px;
            display: inline-block;
            margin:0;

        }

        .status-ditolak p {
            background-color: red;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            display: inline-block;
            margin:0;

        }

        .status-diterima p {
            background-color: green;
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            display: inline-block;
            margin:0;
        }



        /* Styling untuk pagination */
        .pagination {
            display: inline-block;
            padding: 10px;
            list-style-type: none;
            border-radius: 5px;
            background-color: #f8f9fa;
        }

        .pagination a {
            padding: 8px 16px;
            margin: 0 4px;
            text-decoration: none;
            color: #007bff;
            border: 1px solid #ddd;
            border-radius: 3px;
        }

        .pagination a:hover {
            background-color: #ddd;
        }

        .pagination .active a {
            background-color: #007bff;
            color: white;
            border: none;
        }
        .tab-button.active {
            background-color: #6C757D; /* Warna biru untuk tab yang aktif */
            color: white;
            border: 1px solid #6C757D;
        }
    </style>
</head>
<body>

<div class="search-container">
    <div class="search-box">
        <h2>Cari Nama Siswa Disini</h2>
        <input type="text" id="search-input" placeholder="Ketik sesuatu disini">
    </div>
</div>


<!-- Tabel Data Siswa -->
<div class="container mt-4">

    <!-- Tab untuk Jenjang Pendidikan -->
    <div class="tabs">
        <button class="tab-button <?php echo ($jenjang == 'TK') ? 'active' : ''; ?>" onclick="filterJenjang('TK')">TK</button>
        <button class="tab-button <?php echo ($jenjang == 'SD') ? 'active' : ''; ?>" onclick="filterJenjang('SD')">SD</button>
        <button class="tab-button <?php echo ($jenjang == 'SMP') ? 'active' : ''; ?>" onclick="filterJenjang('SMP')">SMP</button>
    </div>

<!-- Wrapper untuk membuat tabel bisa di-scroll horizontal -->
<div class="table-responsive">
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Lengkap</th>
                <th>Jenjang Pendidikan</th>
                <th>Jenis Kelamin</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $query = "SELECT * FROM siswa WHERE jenjang_pendidikan = '$jenjang' LIMIT $limit OFFSET $offset";
            $result = $conn->query($query);

            if ($result->num_rows > 0) {
                $no = $offset + 1;
                while ($row = $result->fetch_assoc()) {
                    $status_class = '';
                    if ($row['status'] == 'Pending') {
                        $status_class = 'status-pending';
                    } elseif ($row['status'] == 'Ditolak') {
                        $status_class = 'status-ditolak';
                    } elseif ($row['status'] == 'Diterima') {
                        $status_class = 'status-diterima';
                    }
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td><?php echo htmlspecialchars($row['nama_lengkap']); ?></td>
                        <td><?php echo htmlspecialchars($row['jenjang_pendidikan']); ?></td>
                        <td><?php echo htmlspecialchars($row['jenis_kelamin']); ?></td>
                        <td class="<?php echo $status_class; ?>"><p><?php echo htmlspecialchars($row['status']); ?></p></td>
                    </tr>
                <?php } ?>
            <?php
            } else {
                echo "<tr><td colspan='5' class='no-data'>Tidak ada data yang tersedia.</td></tr>";
            }
            ?>
        </tbody>
    </table>
</div>

    <!-- Pagination -->
    <div class="pagination">
        <?php if ($page > 1): ?>
            <a href="?page=<?php echo $page - 1; ?>&jenjang=<?php echo $jenjang; ?>">&laquo; Prev</a>
        <?php endif; ?>
        <?php for ($i = 1; $i <= $total_pages; $i++): ?>
            <li class="<?php echo ($i == $page) ? 'active' : ''; ?>">
                <a href="?page=<?php echo $i; ?>&jenjang=<?php echo $jenjang; ?>"><?php echo $i; ?></a>
            </li>
        <?php endfor; ?>
        <?php if ($page < $total_pages): ?>
            <a href="?page=<?php echo $page + 1; ?>&jenjang=<?php echo $jenjang; ?>">Next &raquo;</a>
        <?php endif; ?>
    </div>
</div>



<?php
include('../includes/footer.php');
$conn->close();
?>

<script>
    // Fungsi untuk mengubah jenjang yang aktif
    function filterJenjang(jenjang) {
        // Menyusun URL dengan query string untuk jenjang yang dipilih
        window.location.href = "?page=1&jenjang=" + jenjang;
    }





    document.addEventListener('DOMContentLoaded', function () {
    const searchInput = document.getElementById('search-input');
    const tableRows = document.querySelectorAll('table tbody tr');
    const jenjangAktif = '<?php echo $jenjang; ?>'; // Ambil jenjang yang aktif dari PHP

    // Fungsi untuk melakukan pencarian
    searchInput.addEventListener('input', function () {
        const searchTerm = searchInput.value.toLowerCase();

        tableRows.forEach(row => {
            // Mendapatkan jenjang dari kolom
            const rowJenjang = row.cells[2].textContent.trim().toLowerCase(); // Kolom ke-3 adalah Jenjang Pendidikan
            const rowNama = row.cells[1].textContent.trim().toLowerCase(); // Kolom ke-2 adalah Nama Lengkap

            // Cek apakah baris sesuai dengan jenjang yang aktif dan apakah nama mencocokkan kata kunci
            if (rowJenjang === jenjangAktif.toLowerCase() && rowNama.includes(searchTerm)) {
                row.style.display = '';  // Tampilkan baris
            } else {
                row.style.display = 'none';  // Sembunyikan baris
            }
        });
    });
});

</script>

</body>
</html>
