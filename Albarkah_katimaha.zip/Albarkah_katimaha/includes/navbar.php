<nav class="navbar navbar-expand-lg navbar-light bg-white border">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand" href="#">
            <img src="../images/logo-nav.png" alt="Logo" class="img-fluid logo-navbar">
        </a>

        <!-- Burger Icon (Toggling menu) -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <!-- Navbar Links -->
        <div class="collapse navbar-collapse justify-content-center" id="navbarNav">
            <ul class="navbar-nav d-flex align-items-center gap-4">
                <li class="nav-item">
                    <a class="nav-link beranda" href="../pages/index.php">Beranda</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link daftar-siswa" href="../pages/daftar_siswa.php">Daftar Siswa Baru</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link kontak" href="../pages/kontak_kami.php">Kontak Kami</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link tentang-kami" href="../pages/tentang_kami.php">Tentang Kami</a>
                </li>

                <!-- Login Button (Ikut masuk ke dalam menu) -->
                <li class="nav-item loginButton">
                    <a href="../pages/login.php" class="btn btn-secondary">Login Admin</a>
                </li>
            </ul>
        </div>
    </div>
</nav>
