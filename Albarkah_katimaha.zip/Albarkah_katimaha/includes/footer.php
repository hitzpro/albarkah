<footer class="footer">
    <img src="../images/logo-nav.png" alt="">
    <p>Copyright © 2025 Wakhid Khoirul Aziz | All Rights Reserved </p>
</footer>