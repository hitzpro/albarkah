-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 15 Apr 2025 pada 16.57
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `albarkah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE `admin` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_login` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `is_login`) VALUES
(1, 'albarkah2024', 'eb7543396996e22ee4cf2e7c09e88349', '0');

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id` bigint(20) NOT NULL,
  `jenjang_pendidikan` enum('TK','SD','SMP') NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `nama_panggilan` varchar(255) NOT NULL,
  `tempat_tanggal_lahir` varchar(255) NOT NULL,
  `umur` int(11) NOT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') NOT NULL,
  `anak_ke` int(11) NOT NULL,
  `jumlah_saudara` int(11) NOT NULL,
  `alamat_murid` text NOT NULL,
  `nisn` varchar(15) DEFAULT NULL,
  `nilai_akhir` int(11) DEFAULT NULL,
  `nilai_rata_rata` int(11) DEFAULT NULL,
  `alumni_sd` varchar(255) DEFAULT NULL,
  `nama_ayah` varchar(255) NOT NULL,
  `nama_ibu` varchar(255) NOT NULL,
  `pendidikan_ayah` varchar(255) NOT NULL,
  `pendidikan_ibu` varchar(255) NOT NULL,
  `pekerjaan_ayah` varchar(255) NOT NULL,
  `pekerjaan_ibu` varchar(255) NOT NULL,
  `agama_ortu` varchar(255) NOT NULL,
  `nomer_telepon_ortu` varchar(15) NOT NULL,
  `nama_wali` varchar(255) NOT NULL,
  `pendidikan_wali` varchar(255) NOT NULL,
  `pekerjaan_wali` varchar(255) NOT NULL,
  `agama_wali` varchar(255) NOT NULL,
  `nomer_telepon_wali` varchar(255) NOT NULL,
  `alamat_wali` text NOT NULL,
  `akte_kelahiran` enum('Ada','Tidak Ada') NOT NULL,
  `kartu_keluarga` enum('Ada','Tidak Ada') NOT NULL,
  `foto_murid` enum('Ada','Tidak Ada') NOT NULL,
  `bukti_pembayaran` enum('Ada','Tidak Ada') NOT NULL,
  `nik` int(20) NOT NULL,
  `bukti_ktp` enum('Ada','Tidak Ada') NOT NULL,
  `status` enum('Pending','Diterima','Ditolak') NOT NULL,
  `penghasilan_ayah` decimal(15,2) DEFAULT NULL,
  `penghasilan_ibu` decimal(15,2) DEFAULT NULL,
  `penghasilan_wali` decimal(15,2) DEFAULT NULL,
  `status_pindahan` enum('Bukan','Pindahan') DEFAULT 'Bukan'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id`, `jenjang_pendidikan`, `nama_lengkap`, `nama_panggilan`, `tempat_tanggal_lahir`, `umur`, `jenis_kelamin`, `anak_ke`, `jumlah_saudara`, `alamat_murid`, `nisn`, `nilai_akhir`, `nilai_rata_rata`, `alumni_sd`, `nama_ayah`, `nama_ibu`, `pendidikan_ayah`, `pendidikan_ibu`, `pekerjaan_ayah`, `pekerjaan_ibu`, `agama_ortu`, `nomer_telepon_ortu`, `nama_wali`, `pendidikan_wali`, `pekerjaan_wali`, `agama_wali`, `nomer_telepon_wali`, `alamat_wali`, `akte_kelahiran`, `kartu_keluarga`, `foto_murid`, `bukti_pembayaran`, `nik`, `bukti_ktp`, `status`, `penghasilan_ayah`, `penghasilan_ibu`, `penghasilan_wali`, `status_pindahan`) VALUES
(17, 'TK', 'wakhid khoirul aziz', 'wakhid', 'Kebumen, 22 Agustus 2004', 9, 'Laki-laki', 1, 2, 'BantarGebang Bekasi', NULL, NULL, NULL, NULL, 'Slamet Riyadi', 'wakhidatul Khusnul khotimah', 'SMA', 'SMA', 'pegawai Swasta', 'irt', 'islam', '081336889643', '', '', '', '', '', '', 'Ada', 'Ada', 'Ada', 'Ada', 0, 'Ada', 'Pending', NULL, NULL, NULL, 'Bukan'),
(20, 'TK', 'Batara Nanda', 'Batara', 'Kebumen, 22 Agustus 2004', 5, 'Laki-laki', 2, 2, 'BantarGebang Bekasi', NULL, NULL, NULL, NULL, 'Joko', 'Fuji', 'SMA', 'SMA', 'pegawai Swasta', 'irt', 'islam', '2147483647', '', '', '', '', '', '', 'Ada', 'Ada', 'Ada', 'Ada', 0, 'Ada', 'Ditolak', NULL, NULL, NULL, 'Bukan'),
(22, 'TK', 'wahyu', 'wahyu', 'Bekasi 23 Januari 2011', 5, 'Laki-laki', 2, 1, 'bekasi', NULL, NULL, NULL, NULL, 'Joko', 'Fuji', 'SMA', 'SMA', 'pegawai Swasta', 'irt', 'islam', '6287864333383', '', '', '', '', '', '', 'Ada', 'Ada', 'Ada', 'Ada', 0, 'Ada', 'Diterima', NULL, NULL, NULL, 'Bukan');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `admin`
--
ALTER TABLE `admin`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=30;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
