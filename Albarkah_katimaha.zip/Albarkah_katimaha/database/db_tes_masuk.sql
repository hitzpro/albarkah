-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 15 Apr 2025 pada 16.57
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_tes_masuk`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `jawaban_siswa`
--

CREATE TABLE `jawaban_siswa` (
  `id` int(11) NOT NULL,
  `siswa_id` int(11) NOT NULL,
  `soal_id` int(11) NOT NULL,
  `jawaban` enum('A','B','C','D') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `nilai`
--

CREATE TABLE `nilai` (
  `id` int(11) NOT NULL,
  `siswa_id` int(11) NOT NULL,
  `nilai` decimal(5,2) NOT NULL,
  `total_benar` int(11) NOT NULL,
  `total_soal` int(11) NOT NULL,
  `tanggal_penilaian` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `jenjang` enum('SDIT','SMPIT') NOT NULL,
  `video_membaca` varchar(255) DEFAULT NULL,
  `foto_tulisan` varchar(255) DEFAULT NULL,
  `video_quran` varchar(255) DEFAULT NULL,
  `tanggal_daftar` datetime NOT NULL,
  `kelas` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `soal`
--

CREATE TABLE `soal` (
  `id` int(11) NOT NULL,
  `jenjang` enum('SDIT','SMPIT') NOT NULL,
  `kategori` enum('Matematika','Wawasan Islam') NOT NULL,
  `pertanyaan` text NOT NULL,
  `opsi_a` text NOT NULL,
  `opsi_b` text NOT NULL,
  `opsi_c` text NOT NULL,
  `opsi_d` text NOT NULL,
  `kunci_jawaban` enum('A','B','C','D') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `soal`
--

INSERT INTO `soal` (`id`, `jenjang`, `kategori`, `pertanyaan`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `kunci_jawaban`) VALUES
(1, 'SDIT', 'Matematika', 'Hasil dari 25 + 37 adalah...', '52', '62', '72', '82', 'B'),
(2, 'SDIT', 'Matematika', 'Jika saya memiliki 24 permen dan dibagikan kepada 6 orang sama rata, berapa permen yang diterima setiap orang?', '3', '4', '5', '6', 'B'),
(3, 'SDIT', 'Matematika', 'Berapakah hasil dari 8 x 7?', '54', '56', '58', '60', 'B'),
(4, 'SDIT', 'Matematika', 'Sebuah persegi panjang memiliki panjang 12 cm dan lebar 8 cm. Berapakah luasnya?', '20 cm?', '60 cm?', '96 cm?', '120 cm?', 'C'),
(5, 'SDIT', 'Matematika', 'Jika 5 x n = 45, maka nilai n adalah...', '7', '8', '9', '10', 'C'),
(6, 'SDIT', 'Matematika', 'Bilangan 729 jika dibulatkan ke puluhan terdekat menjadi...', '700', '720', '730', '740', 'C'),
(7, 'SDIT', 'Matematika', 'Hasil dari 156 - 87 adalah...', '59', '69', '79', '89', 'B'),
(8, 'SDIT', 'Matematika', 'Ali memiliki 3 lusin kelereng. Jika 1 lusin berisi 12 kelereng, berapa jumlah kelereng Ali?', '24', '36', '48', '60', 'B'),
(9, 'SDIT', 'Matematika', 'Jika hari ini hari Selasa, maka dua hari lagi adalah hari...', 'Rabu', 'Kamis', 'Jumat', 'Sabtu', 'B'),
(10, 'SDIT', 'Matematika', 'Urutan bilangan dari yang terkecil: 45, 12, 78, 30 adalah...', '12, 30, 45, 78', '30, 12, 45, 78', '78, 45, 30, 12', '45, 12, 30, 78', 'A'),
(11, 'SMPIT', 'Wawasan Islam', 'Siapa nama kakek Nabi Muhammad SAW?', 'Abdul Muttalib', 'Abu Thalib', 'Abu Lahab', 'Abu Sufyan', 'A'),
(12, 'SMPIT', 'Wawasan Islam', 'Perang pertama dalam Islam adalah?', 'Perang Uhud', 'Perang Badar', 'Perang Tabuk', 'Perang Khandaq', 'B'),
(13, 'SMPIT', 'Wawasan Islam', 'Siapa khalifah pertama setelah wafatnya Nabi Muhammad SAW?', 'Umar bin Khattab', 'Utsman bin Affan', 'Abu Bakar Ash-Shiddiq', 'Ali bin Abi Thalib', 'C'),
(14, 'SMPIT', 'Wawasan Islam', 'Apa nama tempat hijrah Nabi Muhammad SAW?', 'Mekkah', 'Yaman', 'Thaif', 'Madinah', 'D'),
(15, 'SMPIT', 'Wawasan Islam', 'Perjanjian Hudaibiyah terjadi antara kaum Muslimin dan?', 'Yahudi Khaibar', 'Quraisy', 'Nasrani Najran', 'Persia', 'B'),
(16, 'SMPIT', 'Wawasan Islam', 'Apa nama gua tempat Nabi menerima wahyu pertama?', 'Gua Hira', 'Gua Tsur', 'Gua Uhud', 'Gua Badar', 'A'),
(17, 'SMPIT', 'Wawasan Islam', 'Siapa panglima muda yang menaklukkan Konstantinopel?', 'Shalahuddin Al-Ayyubi', 'Khalid bin Walid', 'Muhammad Al-Fatih', 'Umar bin Abdul Aziz', 'C'),
(18, 'SMPIT', 'Wawasan Islam', 'Kitab suci umat Islam adalah?', 'Taurat', 'Injil', 'Zabur', 'Al-Qur\'an', 'D'),
(19, 'SMPIT', 'Wawasan Islam', 'Kota suci ketiga setelah Makkah dan Madinah?', 'Baghdad', 'Yerusalem', 'Damaskus', 'Istanbul', 'B'),
(20, 'SMPIT', 'Wawasan Islam', 'Siapa ibu dari Nabi Muhammad SAW?', 'Khadijah', 'Aisyah', 'Aminah binti Wahb', 'Fatimah', 'C'),
(21, 'SMPIT', 'Matematika', 'Hasil dari 12 x 8 adalah?', '96', '98', '88', '108', 'A'),
(22, 'SMPIT', 'Matematika', 'Bilangan prima antara 10 dan 20 adalah?', '11, 13, 17, 19', '10, 12, 14, 18', '15, 17, 19, 20', '13, 15, 18, 19', 'A'),
(23, 'SMPIT', 'Matematika', 'Jika x = 3, maka nilai dari 2x + 5 adalah?', '11', '10', '9', '8', 'A'),
(24, 'SMPIT', 'Matematika', 'Rumus luas lingkaran adalah?', '?r?', '2?r', 'r?', '?d', 'A'),
(25, 'SMPIT', 'Matematika', 'Hasil dari 81 ? 9 adalah?', '9', '8', '7', '6', 'A'),
(26, 'SMPIT', 'Wawasan Islam', 'Berapa jumlah rukun Islam?', '3', '4', '5', '6', 'C'),
(27, 'SMPIT', 'Wawasan Islam', 'Apa nama malam saat Al-Qur\'an pertama kali diturunkan?', 'Malam Idul Fitri', 'Malam Isra Miraj', 'Lailatul Qadar', 'Malam Nisfu Sya\'ban', 'C'),
(28, 'SMPIT', 'Wawasan Islam', 'Apa arti dari kata \"Islam\"?', 'Kemenangan', 'Perdamaian', 'Kepemimpinan', 'Kesatuan', 'B'),
(29, 'SMPIT', 'Wawasan Islam', 'Berapa jumlah shalat wajib dalam sehari?', '3', '4', '5', '6', 'C'),
(30, 'SMPIT', 'Wawasan Islam', 'Zakat fitrah dibayar dengan?', 'Uang saja', 'Emas', 'Makanan pokok', 'Hewan ternak', 'C');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `jawaban_siswa`
--
ALTER TABLE `jawaban_siswa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `siswa_id` (`siswa_id`),
  ADD KEY `soal_id` (`soal_id`);

--
-- Indeks untuk tabel `nilai`
--
ALTER TABLE `nilai`
  ADD PRIMARY KEY (`id`),
  ADD KEY `siswa_id` (`siswa_id`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `soal`
--
ALTER TABLE `soal`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `jawaban_siswa`
--
ALTER TABLE `jawaban_siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT untuk tabel `nilai`
--
ALTER TABLE `nilai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `siswa`
--
ALTER TABLE `siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `soal`
--
ALTER TABLE `soal`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `jawaban_siswa`
--
ALTER TABLE `jawaban_siswa`
  ADD CONSTRAINT `jawaban_siswa_ibfk_1` FOREIGN KEY (`siswa_id`) REFERENCES `siswa` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `jawaban_siswa_ibfk_2` FOREIGN KEY (`soal_id`) REFERENCES `soal` (`id`) ON DELETE CASCADE;

--
-- Ketidakleluasaan untuk tabel `nilai`
--
ALTER TABLE `nilai`
  ADD CONSTRAINT `nilai_ibfk_1` FOREIGN KEY (`siswa_id`) REFERENCES `siswa` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
