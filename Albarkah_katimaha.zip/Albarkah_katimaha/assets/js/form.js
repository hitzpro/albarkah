document.addEventListener("DOMContentLoaded", function () {
    const steps = document.querySelectorAll('.tk-step');
    const stepContents = document.querySelectorAll('.step-content');
    const nextButton = document.querySelector('#nextBtn');
    const submitButton = document.querySelector('.tk-submit-button');
    const stepIndicators = document.querySelectorAll('.tk-step');

    let currentStep = 1; // Step default saat halaman dimuat adalah Step 1

    // Menampilkan Step pertama saat halaman dimuat
    setActiveStep(currentStep);

// Fungsi untuk mengatur step yang aktif
function setActiveStep(stepNumber) {
    // Menyembunyikan Step yang tidak aktif
    stepContents.forEach(content => {
        content.classList.remove('active');
        if (content.dataset.step == stepNumber) {
            content.classList.add('active');
        }
    });

    // Mengatur langkah-langkah yang telah dilalui
    steps.forEach(step => {
        step.classList.remove('active');
        if (parseInt(step.dataset.step) <= stepNumber) {
            step.classList.add('completed');
        }
    });

    // Mengatur indikator warna
    updateIndicators(stepNumber);

    // Menampilkan tombol selanjutnya atau kirim berdasarkan step
    if (stepNumber === 5) {
        submitButton.style.display = "inline-block"; // Tampilkan tombol kirim di Step 5
        nextButton.style.display = "none";           // Sembunyikan tombol next

        // Tampilkan elemen confuse dan messege
        document.querySelector('.confuse1').style.display = "inline-block";
        document.querySelector('.messege').style.display = "inline-block";

        // Sembunyikan syarat unggah file
        document.querySelector('.unggah-file').style.display = "none";
        document.querySelector('.unggah-file-list').style.display = "none";
        document.querySelector('.messege-wali').style.display = "none";

    } else {
        submitButton.style.display = "none";       // Sembunyikan tombol kirim
        nextButton.style.display = "inline-block"; // Tampilkan tombol next

        // Sembunyikan elemen confuse dan messege
        document.querySelector('.confuse').style.display = "none";
        document.querySelector('.messege').style.display = "none";

        // Menampilkan syarat unggah file hanya jika berada di Step 4
        if (stepNumber === 4) {
            document.querySelector('.unggah-file').style.display = "inline-block";
            document.querySelector('.unggah-file-list').style.display = "inline-block";
        } else {
            document.querySelector('.unggah-file').style.display = "none";
            document.querySelector('.unggah-file-list').style.display = "none";
        }

        // Menampilkan pesan sesuai dengan step aktif
        if (stepNumber === 2) {
            // Tampilkan pesan untuk orang tua saat berada di Step 2
            document.querySelector('.messege-ortu').style.display = "block";
        } else {
            document.querySelector('.messege-ortu').style.display = "none";
        }

        if (stepNumber === 3) {
            // Tampilkan pesan untuk wali dan gambar confuse1 saat berada di Step 3
            document.querySelector('.messege-wali').style.display = "block";
            document.querySelector('.confuse1').style.display = "block";
        } else {
            document.querySelector('.messege-wali').style.display = "none";
            document.querySelector('.confuse1').style.display = "none";
        }
    }

    // Melakukan scroll otomatis ke step yang aktif
    scrollToStep(stepNumber);

    // Validasi input di setiap step
    validateStep(stepNumber);
}



    // Fungsi untuk memperbarui warna indikator sesuai dengan langkah
    function updateIndicators(stepNumber) {
        stepIndicators.forEach(indicator => {
            const indicatorStep = parseInt(indicator.dataset.step);
            if (indicatorStep <= stepNumber) {
                // Indikator yang sudah dilalui atau sedang aktif, beri warna
                indicator.classList.add('completed');
            } else {
                // Indikator yang belum dilalui, hilangkan warna
                indicator.classList.remove('completed');
            }
        });
    }

    // Tombol Next untuk berpindah ke step berikutnya
    if (nextButton) {
        nextButton.addEventListener('click', function () {
            if (currentStep < 5) {
                currentStep++;
                setActiveStep(currentStep);
            }
        });
    }

    // Fungsi untuk scroll ke step tertentu
    function scrollToStep(stepNumber) {
        const targetStep = document.querySelector(`.step-content[data-step="${stepNumber}"]`);
        window.scrollTo({
            top: targetStep.offsetTop,
            behavior: 'smooth'
        });
    }

    // Fungsi untuk memvalidasi input pada setiap step
    function validateStep(stepNumber) {
        const inputs = document.querySelectorAll(`.step-content[data-step="${stepNumber}"] input, .step-content[data-step="${stepNumber}"] textarea`);
        inputs.forEach(input => {
            input.addEventListener('input', function () {
                const step = document.querySelector(`.tk-step[data-step="${stepNumber}"]`);
                if (input.value.trim() !== "") {
                    step.classList.add('completed');
                } else {
                    step.classList.remove('completed');
                }
            });
        });
    }

    // Klik pada indikator untuk berpindah antar langkah
    stepIndicators.forEach(step => {
        step.addEventListener('click', function () {
            const stepNumber = this.dataset.step;
            currentStep = parseInt(stepNumber);
            setActiveStep(currentStep);
        });
    });
});




