<?php
include('../config/db.php'); // Include database connection

// Pastikan data yang dikirim adalah valid
if (isset($_POST['id']) && isset($_POST['status'])) {
    $id = $_POST['id'];
    $status = $_POST['status'];

    // Query untuk memperbarui status siswa
    $query = "UPDATE siswa SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('si', $status, $id);

    // Eksekusi query dan cek apakah berhasil
    if ($stmt->execute()) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false]);
    }

    $stmt->close();
}

$conn->close();
?>
