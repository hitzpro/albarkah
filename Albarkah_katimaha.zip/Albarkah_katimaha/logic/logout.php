<?php
session_start();

// Hapus session yang aktif
session_unset();

// Hapus session ID
session_destroy();

// Redirect ke halaman login setelah logout
header("Location: ../pages/login.php");
exit();
?>
