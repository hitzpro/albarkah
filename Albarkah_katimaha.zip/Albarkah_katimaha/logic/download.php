<?php
include '../config/db.php';
require '../vendor/autoload.php'; // Autoload dari Composer

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Ambil parameter jenjang dari URL
$jenjang = $_GET['jenjang'] ?? '';

// Cek apakah jenjang valid
if (!in_array($jenjang, ['TK', 'SD', 'SMP'])) {
    die('Invalid Jenjang');
}

// Ambil data berdasarkan jenjang
$sql = "SELECT * FROM siswa WHERE jenjang_pendidikan = '$jenjang'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Buat spreadsheet baru
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Set header Excel (menyesuaikan dengan kolom-kolom di tabel siswa)
    $sheet->setCellValue('A1', 'No')
          ->setCellValue('B1', 'Jenjang Pendidikan')
          ->setCellValue('C1', 'Nama Lengkap')
          ->setCellValue('D1', 'Nama Panggilan')
          ->setCellValue('E1', 'Tempat, Tanggal Lahir')
          ->setCellValue('F1', 'Umur')
          ->setCellValue('G1', 'Jenis Kelamin')
          ->setCellValue('H1', 'Anak Ke')
          ->setCellValue('I1', 'Jumlah Saudara')
          ->setCellValue('J1', 'Alamat Murid')
          ->setCellValue('K1', 'NISN')
          ->setCellValue('L1', 'Nilai Akhir')
          ->setCellValue('M1', 'Nilai Rata-Rata')
          ->setCellValue('N1', 'Alumni SD')
          ->setCellValue('O1', 'Nama Ayah')
          ->setCellValue('P1', 'Nama Ibu')
          ->setCellValue('Q1', 'Pendidikan Ayah')
          ->setCellValue('R1', 'Pendidikan Ibu')
          ->setCellValue('S1', 'Pekerjaan Ayah')
          ->setCellValue('T1', 'Pekerjaan Ibu')
          ->setCellValue('U1', 'Agama Orang Tua')
          ->setCellValue('V1', 'Nomor Telepon Orang Tua')
          ->setCellValue('W1', 'Nama Wali')
          ->setCellValue('X1', 'Pendidikan Wali')
          ->setCellValue('Y1', 'Pekerjaan Wali')
          ->setCellValue('Z1', 'Agama Wali')
          ->setCellValue('AA1', 'Nomor Telepon Wali')
          ->setCellValue('AB1', 'Alamat Wali')
          ->setCellValue('AC1', 'Akte Kelahiran')
          ->setCellValue('AD1', 'Kartu Keluarga')
          ->setCellValue('AE1', 'Foto Murid')
          ->setCellValue('AF1', 'Bukti Pembayaran')
          ->setCellValue('AG1', 'NIK')
          ->setCellValue('AH1', 'Bukti KTP')
          ->setCellValue('AI1', 'Status')
          ->setCellValue('AJ1', 'Penghasilan Ayah')
          ->setCellValue('AK1', 'Penghasilan Ibu')
          ->setCellValue('AL1', 'Penghasilan Wali');

    // Styling untuk header
    $styleArrayHeader = [
        'font' => [
            'bold' => true,
            'color' => ['rgb' => 'FFFFFF'],
            'size' => 12,
        ],
        'fill' => [
            'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
            'startColor' => ['rgb' => '4CAF50'], // Hijau
        ],
        'alignment' => [
            'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_CENTER,
            'vertical' => \PhpOffice\PhpSpreadsheet\Style\Alignment::VERTICAL_CENTER,
        ]
    ];

    $sheet->getStyle('A1:AL1')->applyFromArray($styleArrayHeader);

    // Menambahkan data siswa ke spreadsheet
    $row = 2; // Mulai dari baris kedua
    $no = 1; // Nomor urut mulai dari 1
    while ($data = $result->fetch_assoc()) {
        $sheet->setCellValue('A' . $row, $no++) // Nomor urut
              ->setCellValue('B' . $row, $data['jenjang_pendidikan'])
              ->setCellValue('C' . $row, $data['nama_lengkap'])
              ->setCellValue('D' . $row, $data['nama_panggilan'])
              ->setCellValue('E' . $row, $data['tempat_tanggal_lahir'])
              ->setCellValue('F' . $row, $data['umur'])
              ->setCellValue('G' . $row, $data['jenis_kelamin'])
              ->setCellValue('H' . $row, $data['anak_ke'])
              ->setCellValue('I' . $row, $data['jumlah_saudara'])
              ->setCellValue('J' . $row, $data['alamat_murid'])
              ->setCellValue('K' . $row, $data['nisn'])
              ->setCellValue('L' . $row, $data['nilai_akhir'])
              ->setCellValue('M' . $row, $data['nilai_rata_rata'])
              ->setCellValue('N' . $row, $data['alumni_sd'])
              ->setCellValue('O' . $row, $data['nama_ayah'])
              ->setCellValue('P' . $row, $data['nama_ibu'])
              ->setCellValue('Q' . $row, $data['pendidikan_ayah'])
              ->setCellValue('R' . $row, $data['pendidikan_ibu'])
              ->setCellValue('S' . $row, $data['pekerjaan_ayah'])
              ->setCellValue('T' . $row, $data['pekerjaan_ibu'])
              ->setCellValue('U' . $row, $data['agama_ortu'])
              ->setCellValue('V' . $row, $data['nomer_telepon_ortu'])
              ->setCellValue('W' . $row, $data['nama_wali'])
              ->setCellValue('X' . $row, $data['pendidikan_wali'])
              ->setCellValue('Y' . $row, $data['pekerjaan_wali'])
              ->setCellValue('Z' . $row, $data['agama_wali'])
              ->setCellValue('AA' . $row, $data['nomer_telepon_wali'])
              ->setCellValue('AB' . $row, $data['alamat_wali'])
              ->setCellValue('AC' . $row, $data['akte_kelahiran'])
              ->setCellValue('AD' . $row, $data['kartu_keluarga'])
              ->setCellValue('AE' . $row, $data['foto_murid'])
              ->setCellValue('AF' . $row, $data['bukti_pembayaran'])
              ->setCellValue('AG' . $row, $data['nik'])
              ->setCellValue('AH' . $row, $data['bukti_ktp'])
              ->setCellValue('AI' . $row, $data['status'])
              ->setCellValue('AJ' . $row, $data['penghasilan_ayah'])
              ->setCellValue('AK' . $row, $data['penghasilan_ibu'])
              ->setCellValue('AL' . $row, $data['penghasilan_wali']);
        $row++;
    }

    // Menyesuaikan lebar kolom dengan isi konten dan header
    foreach (range('A', 'AL') as $col) {
        // Ambil nilai header
        $header = $sheet->getCell($col . '1')->getValue(); 
        $maxLength = mb_strlen($header); // Pakai mb_strlen untuk mendukung karakter multibyte

        // Faktor penyesuaian agar lebih akurat dalam ukuran Excel
        $factor = 1.2;

        // Loop untuk semua baris dan ambil panjang konten
        for ($row = 2; $row <= $sheet->getHighestRow(); $row++) {
            $cellValue = $sheet->getCell($col . $row)->getValue();
            $cellLength = is_null($cellValue) ? 0 : mb_strlen($cellValue);
            $maxLength = max($maxLength, $cellLength);
        }

        // Set lebar kolom dengan faktor tambahan agar lebih rapi
        $adjustedWidth = $maxLength * $factor + 2;
        $sheet->getColumnDimension($col)->setWidth($adjustedWidth);

        // Tambahkan auto size sebagai fallback
        $sheet->getColumnDimension($col)->setAutoSize(true);
    }



    // Buat file Excel dan unduh
    $writer = new Xlsx($spreadsheet);
    $filename = 'data_siswa_' . $jenjang . '.xlsx';

    // Set header untuk download file
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');

    $writer->save('php://output');
} else {
    echo 'Data tidak ditemukan.';
}

$conn->close();
?>
