<?php
// Memasukkan konfigurasi database
include('../config/db.php');

// Mengambil data dari form
$jenjang_pendidikan = 'SD'; // Karena ini untuk anak TK, kita set ke 'TK'
$nama_lengkap = $_POST['nama_lengkap'] ?? NULL;
$nama_panggilan = $_POST['nama_panggilan'] ?? NULL;
$tempat_tanggal_lahir = $_POST['tempat_tanggal_lahir'] ?? NULL;
$umur = $_POST['umur'] ?? NULL;
$jenis_kelamin = $_POST['jekel'] ?? NULL;
$anak_ke = $_POST['anak_ke'] ?? NULL;
$jml_saudara = $_POST['jml_saudara'] ?? NULL;
$alamat = $_POST['alamat'] ?? NULL;
$status_pindahan = $_POST['status_pindahan'] ?? 'Bukan'; // Default 'Bukan'

// Kolom optional yang bisa kosong
$alumni_sd = empty($_POST['alumni_sd']) ? NULL : $_POST['alumni_sd'];
$nilai_akhir = empty($_POST['nilai_akhir']) ? NULL : $_POST['nilai_akhir'];
$nilai_rata_rata = empty($_POST['nilai_rata_rata']) ? NULL : $_POST['nilai_rata_rata'];

// Data Orang Tua
$nama_ayah = $_POST['nama_ayah'] ?? NULL;
$nama_ibu = $_POST['nama_ibu'] ?? NULL;
$pendidikan_ayah = $_POST['pendidikan_ayah'] ?? NULL;
$pendidikan_ibu = $_POST['pendidikan_ibu'] ?? NULL;
$pekerjaan_ayah = $_POST['pekerjaan_ayah'] ?? NULL;
$pekerjaan_ibu = $_POST['pekerjaan_ibu'] ?? NULL;
$agama_ortu = $_POST['agama_ortu'] ?? NULL;
$no_telp_ortu = $_POST['no_telp_ortu'] ?? NULL;
$alamat_ortu = $_POST['alamat_ortu'] ?? NULL;


// Data Wali
$nama_wali = empty($_POST['nama_wali']) ? NULL : $_POST['nama_wali'];
$pendidikan_wali = empty($_POST['pendidikan_wali']) ? NULL : $_POST['pendidikan_wali'];
$pekerjaan_wali = empty($_POST['pekerjaan_wali']) ? NULL : $_POST['pekerjaan_wali'];
$agama_wali = $_POST['agama_wali'] ?? NULL;
$no_telp_wali = empty($_POST['no_telp_wali']) ? NULL : $_POST['no_telp_wali'];
$alamat_wali = empty($_POST['alamat_wali']) ? NULL : $_POST['alamat_wali'];

// Data Kelengkapan (File)
$akte_kelahiran = isset($_FILES['akte_kelahiran']) ? $_FILES['akte_kelahiran'] : NULL;
$kartu_keluarga = isset($_FILES['kartu_Keluarga']) ? $_FILES['kartu_Keluarga'] : NULL;
$foto_murid = isset($_FILES['foto_murid']) ? $_FILES['foto_murid'] : NULL;

// Data Pembayaran
$bukti_pembayaran = isset($_FILES['bukti_pembayaran']) ? $_FILES['bukti_pembayaran'] : NULL;
$nik = empty($_POST['nik']) ? NULL : $_POST['nik'];
$bukti_ktp = empty($_POST['bukti_ktp']) ? NULL : $_POST['bukti_ktp'];

// Status
$status = 'Pending'; // Default status

// Menyimpan nomor telepon seperti apa adanya, tanpa filter apapun
if ($no_telp_ortu) {
    // Pastikan nomor telepon disimpan sebagai string, jika diperlukan
    $no_telp_ortu = (string) $no_telp_ortu;
}

if ($no_telp_wali) {
    $no_telp_wali = (string) $no_telp_wali;
}


// Mengecek jika umur dan no_telp_ortu adalah angka
if (!is_numeric($umur)) {
    $umur = NULL; // Set umur ke NULL jika tidak valid
}

if (!is_numeric($nik)) {
    $nik = NULL; // Set nik ke NULL jika tidak valid
}

// Tentukan folder berdasarkan jenjang pendidikan dan nama lengkap
$folder_kelompok = '../uploads/' . $jenjang_pendidikan . '/kelengkapan_' . str_replace(' ', '_', $nama_lengkap);
$folder_pembayaran = '../uploads/' . $jenjang_pendidikan . '/bukti_pembayaran_' . str_replace(' ', '_', $nama_lengkap);

// Cek apakah folder untuk kelengkapan dan pembayaran ada, jika tidak maka buat foldernya
if (!file_exists($folder_kelompok)) {
    mkdir($folder_kelompok, 0777, true); // Buat folder kelengkapan
}

if (!file_exists($folder_pembayaran)) {
    mkdir($folder_pembayaran, 0777, true); // Buat folder pembayaran
}

// Fungsi untuk memindahkan file ke folder yang benar
function uploadFile($file, $targetDir, $prefix) {
    $targetFile = $targetDir . '/' . $prefix . '_' . time() . '.' . pathinfo($file['name'], PATHINFO_EXTENSION);
    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        return $targetFile; // Kembalikan lokasi file yang telah diupload
    } else {
        return NULL; // Jika gagal mengupload
    }
}

// Fungsi untuk memeriksa tipe file
function checkFileType($file, $allowedTypes) {
    $fileExt = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    return in_array($fileExt, $allowedTypes);
}

// Inisialisasi status file
$akte_kelahiran_status = 'Tidak Ada';
$kartu_keluarga_status = 'Tidak Ada';
$foto_murid_status = 'Tidak Ada';
$bukti_pembayaran_status = 'Tidak Ada';

// Menyimpan file yang diupload dan mengubah statusnya
if ($akte_kelahiran) {
    if (checkFileType($akte_kelahiran, ['pdf'])) { // Hanya PDF untuk akte kelahiran
        $akte_kelahiran_path = uploadFile($akte_kelahiran, $folder_kelompok, 'akteKelahiran');
        $akte_kelahiran_status = 'Ada'; // Mengubah status menjadi 'Ada'
    } else {
        $akte_kelahiran_path = NULL;
    }
}

if ($kartu_keluarga) {
    if (checkFileType($kartu_keluarga, ['pdf'])) { // Hanya PDF untuk kartu keluarga
        $kartu_keluarga_path = uploadFile($kartu_keluarga, $folder_kelompok, 'kartuKeluarga');
        $kartu_keluarga_status = 'Ada'; // Mengubah status menjadi 'Ada'
    } else {
        $kartu_keluarga_path = NULL;
    }
}

if ($foto_murid) {
    if (checkFileType($foto_murid, ['jpg', 'png'])) { // Hanya JPG dan PNG untuk foto murid
        $foto_murid_path = uploadFile($foto_murid, $folder_kelompok, 'fotoMurid');
        $foto_murid_status = 'Ada'; // Mengubah status menjadi 'Ada'
    } else {
        $foto_murid_path = NULL;
    }
}

if ($bukti_pembayaran) {
    if (checkFileType($bukti_pembayaran, ['pdf', 'jpg', 'png'])) { // PDF, JPG, PNG untuk bukti pembayaran
        $bukti_pembayaran_path = uploadFile($bukti_pembayaran, $folder_pembayaran, 'bukti');
        $bukti_pembayaran_status = 'Ada'; // Mengubah status menjadi 'Ada'
    } else {
        $bukti_pembayaran_path = NULL;
    }
}







// Menyiapkan query SQL biasa
$query = "INSERT INTO siswa (
    jenjang_pendidikan, 
    nama_lengkap, 
    nama_panggilan, 
    tempat_tanggal_lahir, 
    umur, 
    jenis_kelamin, 
    anak_ke, 
    jumlah_saudara, 
    alamat_murid, 
    nama_ayah, 
    nama_ibu, 
    pendidikan_ayah, 
    pendidikan_ibu, 
    pekerjaan_ayah, 
    pekerjaan_ibu, 
    agama_ortu, 
    nomer_telepon_ortu, 
    nama_wali, 
    pendidikan_wali, 
    pekerjaan_wali, 
    agama_wali, 
    nomer_telepon_wali, 
    alamat_wali, 
    akte_kelahiran, 
    kartu_keluarga, 
    foto_murid, 
    bukti_pembayaran, 
    nik, 
    bukti_ktp, 
    status_pindahan,
    status
) VALUES (
    '$jenjang_pendidikan', 
    '$nama_lengkap', 
    '$nama_panggilan', 
    '$tempat_tanggal_lahir', 
    '$umur', 
    '$jenis_kelamin', 
    '$anak_ke', 
    '$jml_saudara', 
    '$alamat', 
    '$nama_ayah', 
    '$nama_ibu', 
    '$pendidikan_ayah', 
    '$pendidikan_ibu', 
    '$pekerjaan_ayah', 
    '$pekerjaan_ibu', 
    '$agama_ortu', 
    '$no_telp_ortu', 
    '$nama_wali', 
    '$pendidikan_wali', 
    '$pekerjaan_wali', 
    '$agama_wali', 
    '$no_telp_wali', 
    '$alamat_wali', 
    '$akte_kelahiran_status', 
    '$kartu_keluarga_status', 
    '$foto_murid_status', 
    '$bukti_pembayaran_status', 
    '$nik', 
    '$bukti_ktp', 
    '$status_pindahan',
    '$status'
)";

// Menjalankan query
if ($conn->query($query)) {
    // Data berhasil disimpan
    session_start();
    $_SESSION['message'] = 'Data berhasil disimpan!';
    $_SESSION['message_type'] = 'success';
} else {
    // Terjadi kesalahan saat menyimpan data
    session_start();
    $_SESSION['message'] = 'Terjadi kesalahan saat menyimpan data: ' . $conn->error;
    $_SESSION['message_type'] = 'error';
}

// Menutup koneksi
$conn->close();

// Redirect kembali ke halaman form
header('Location: ' . $_SERVER['HTTP_REFERER']);
exit();
?>
