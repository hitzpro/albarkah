<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hapus Data</title>
</head>
<body>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

</body>
</html>
<?php
// Memasukkan koneksi database
include('../config/db.php');

// Ambil jenjang pendidikan dari query parameter
$jenjang_pendidikan = $_GET['jenjang_pendidikan'] ?? NULL;

// Pastikan jenjang pendidikan ada
if (!$jenjang_pendidikan) {
    // Jika tidak ada jenjang pendidikan yang dipilih, redirect ke halaman dashboard
    header('Location: ../admin/manajemen_siswa.php');
    exit();
}

// Query untuk memeriksa apakah ada data siswa dengan jenjang pendidikan yang dipilih
$check_query = "SELECT COUNT(*) AS count FROM siswa WHERE jenjang_pendidikan = ?";
$check_stmt = $conn->prepare($check_query);
$check_stmt->bind_param('s', $jenjang_pendidikan);
$check_stmt->execute();
$check_result = $check_stmt->get_result();
$data_count = $check_result->fetch_assoc()['count'];

// Jika tidak ada data siswa dengan jenjang pendidikan tersebut
if ($data_count == 0) {
    // Tampilkan SweetAlert bahwa tidak ada data yang bisa dihapus
    echo "<script>
            Swal.fire({
                icon: 'warning',
                title: 'Tidak Ada Data!',
                text: 'Tidak ada data pendaftaran anak $jenjang_pendidikan yang bisa dihapus.',
                confirmButtonText: 'OK'
            }).then(() => {
                window.location = '../admin/manajemen_siswa.php'; // Redirect ke dashboard
            });
          </script>";
} else {
    // Query untuk menghapus semua data siswa berdasarkan jenjang pendidikan
    $delete_query = "DELETE FROM siswa WHERE jenjang_pendidikan = ?";
    $stmt = $conn->prepare($delete_query);
    $stmt->bind_param('s', $jenjang_pendidikan);

    if ($stmt->execute()) {
        // Jika berhasil menghapus data, tampilkan SweetAlert
        echo "<script>
                Swal.fire({
                    icon: 'success',
                    title: 'Data Berhasil Dihapus!',
                    text: 'Semua data pendaftaran anak $jenjang_pendidikan telah berhasil dihapus.',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location = '../admin/manajemen_siswa.php'; // Redirect setelah hapus
                });
              </script>";
    } else {
        // Jika gagal menghapus data
        echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal Menghapus Data!',
                    text: 'Terdapat kesalahan saat menghapus data siswa.',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location = '../admin/manajemen_siswa.php'; // Redirect kembali jika gagal
                });
              </script>";
    }
}

$conn->close();
?>
