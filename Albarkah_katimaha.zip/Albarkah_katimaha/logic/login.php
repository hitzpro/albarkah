<?php
// Memulai session
session_start();

// Memasukkan koneksi database
include('../config/db.php');

// Mengambil data POST dari form login
$username = $_POST['username'] ?? NULL;
$password = $_POST['password'] ?? NULL;

// Cek apakah username dan password tidak kosong
if (!$username || !$password) {
    // Simpan pesan error di session
    $_SESSION['message'] = [
        'type' => 'error',
        'title' => 'Gagal',
        'text' => 'Username atau Password tidak boleh kosong!',
        'status' => 'failed'
    ];
    // Redirect kembali ke halaman login
    header("Location: ../pages/login.php");
    exit();
}

// Hash password
$password_hashed = md5($password); // Gunakan hashing yang lebih aman di produksi seperti password_hash()

// Query untuk mencari username dan password yang cocok
$query = "SELECT * FROM admin WHERE username = ? AND password = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param('ss', $username, $password_hashed);
$stmt->execute();
$result = $stmt->get_result();

// Jika data ditemukan
if ($result->num_rows > 0) {
    $admin = $result->fetch_assoc();

    // Update status is_login menjadi 1 (aktif) setelah login berhasil
    $update_query = "UPDATE admin SET is_login = 1 WHERE id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param('i', $admin['id']);
    $update_stmt->execute();

    // Mulai session dan simpan data admin yang login
    $_SESSION['admin_id'] = $admin['id'];
    $_SESSION['admin_username'] = $admin['username'];
    $_SESSION['login_time'] = time(); // Simpan waktu login

    // Simpan pesan sukses di session
    $_SESSION['message'] = [
        'type' => 'success',
        'title' => 'Login Berhasil!',
        'text' => 'Selamat datang, Anda berhasil login!',
        'status' => 'success'
    ];
    
    // Redirect ke login page dulu untuk menampilkan SweetAlert
    // Redirect ke login page dulu untuk menampilkan SweetAlert
    header("Location: ../pages/login.php");

    exit();
} else {
    // Jika username atau password salah
    $_SESSION['message'] = [
        'type' => 'error',
        'title' => 'Login Gagal!',
        'text' => 'Username atau Password Salah!',
        'status' => 'failed'
    ];
    header("Location: ../pages/login.php");
    exit();
}

$conn->close();
?>