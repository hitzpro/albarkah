<?php
$host = "localhost";  // Ganti dengan host database jika berbeda
$user = "root";       // Ganti dengan username database
$pass = "";           // Ganti dengan password database
$dbname = "albarkah"; // Ganti dengan nama database yang digunakan

// Membuat koneksi
$conn = new mysqli($host, $user, $pass, $dbname);

// Cek koneksi
if ($conn->connect_error) {
    die("Koneksi gagal: " . $conn->connect_error);
}
?>
